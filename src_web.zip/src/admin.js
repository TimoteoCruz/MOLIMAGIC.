import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faEdit } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';

function Admin() {
  const [usuarios, setUsuarios] = useState([]);
  const [idUsuarioEditando, setIdUsuarioEditando] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    obtenerUsuarios();
  }, []);

  const navigate = useNavigate();

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn");
    if (!loggedIn) {
      navigate("/login", { state: { origen: "inventario" } });
    }
  }, []);

  const origenRedireccion = window.location.state?.origen;

  useEffect(() => {
    if (origenRedireccion === 'inventario') {
      Swal.fire({
        icon: 'info',
        title: 'Necesitas iniciar sesión',
        text: 'para acceder a esta página.'
      });
    }
  }, [origenRedireccion]);

  const obtenerUsuarios = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/admin_get", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setUsuarios(data);
      } else {
        console.error("Los datos obtenidos no son un array:", data);
      }
    } catch (error) {
      console.error("Error al obtener usuarios:", error);
    }
  };

  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  const handleGuardarUsuario = async (e) => {
    e.preventDefault();
    try {
      if (!email || !password) {
        Swal.fire({
          icon: 'error',
          title: 'Campos vacíos',
          text: 'Por favor, completa todos los campos para guardar el usuario.',
        });
        return;
      }

      const url = idUsuarioEditando ? `http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/admin_put` : "http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/admin_post";
      const method = idUsuarioEditando ? "POST" : "POST";

      const requestData = idUsuarioEditando ? { id_us: idUsuarioEditando, email, password } : { email, password };

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      });
      const data = await response.json();
      console.log(data);
      obtenerUsuarios();
      setEmail("");
      setPassword("");
      setIdUsuarioEditando(null);

      Swal.fire({
        icon: 'success',
        title: '¡Usuario guardado!',
        text: 'El usuario se ha guardado correctamente.',
      });
    } catch (error) {
      console.error("Error al guardar usuario:", error);
    }
  };


  const handleEliminarUsuario = async (id) => {
    try {
      const username = 'tu_usuario';
      const password = 'tu_contraseña';
      const credentials = `${username}:${password}`;
      const base64Credentials = btoa(credentials);

      const response = await fetch(`http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/admin_delete?id_us=${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Basic ${base64Credentials}`,
          "X-HTTP-Method-Override": "DELETE"
        },
      });

      if (!response.ok) {
        throw new Error('Error al eliminar el usuario');
      }

      const data = await response.json();
      console.log(data);
      obtenerUsuarios();
      setIdUsuarioEditando(null);

      Swal.fire({
        icon: 'success',
        title: '¡Usuario eliminado!',
        text: 'El usuario se ha eliminado correctamente.',
      });
    } catch (error) {
      console.error("Error al eliminar usuario:", error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Hubo un error al eliminar el usuario. Por favor, inténtalo de nuevo más tarde.',
      });
    }
  };
  


  const handleEditarUsuario = (id) => {
    console.log("Editar usuario con ID:", id);
    const usuarioEditando = usuarios.find(usuario => usuario.id_us === id);
    if (usuarioEditando) {
      const { email: emailInicial, password: passwordInicial } = usuarioEditando;
      if (email === emailInicial && password === passwordInicial) {
        Swal.fire({
          icon: 'info',
          title: 'Sin cambios',
          text: 'No se han realizado cambios en la edición del usuario.',
        });
      } else {
        setIdUsuarioEditando(id);
        setEmail(emailInicial);
        setPassword(passwordInicial);
      }
    }
  };

  return (
    <section className="intro" style={{ height: "100%" }}>
      <div
        className="bg-image-vertical h-100"
        style={{
          position: "relative",
          overflow: "hidden",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "right center",
          backgroundSize: "auto 100%",
          backgroundColor: "#B2AFAF",
          backgroundImage:
            "url(https://img.freepik.com/fotos-premium/conjunto-diferentes-granos-enteros-frijoles-semillas-legumbres_73523-3388.jpg?w=1800)",
        }}
      >
        <div className="mask d-flex align-items-center h-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-lg-10">
                <div className="card" style={{ borderRadius: "1rem" }}>
                  <div className="card-body p-5">
                    <h2 className="mb-5 text-left"> Administradores</h2>

                    <form onSubmit={handleGuardarUsuario}>
                      <div className="row">
                        <div className="col-md-6 mb-4">
                          <div className="row g-4">
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="formGrainType"
                                  className="form-control"
                                  value={email}
                                  onChange={(e) => setEmail(e.target.value)}
                                  placeholder="Correo Electrónico"
                                />
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="formAmount"
                                  className="form-control"
                                  value={password}
                                  onChange={(e) => setPassword(e.target.value)}
                                  placeholder="Contraseña"
                                />
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>
                      <button
                        type="submit"
                        className="btn btn-success btn-rounded btn-block"
                      >
                        {idUsuarioEditando ? 'Actualizar' : 'Guardar'}{" "}
                      </button>
                    </form>
                <br></br>
                    <button
                      className="btn btn-info mb-3"
                      onClick={toggleModal}
                    >
                      Mostrar Lista
                    </button>

                    {modalVisible && (
                      <div className="modal-dialog" role="document">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5 className="modal-title">Tabla de Usuarios</h5>
                           
                          </div>
                          <div className="modal-body">
                            <table className="table table-bordered table-dark mt-5">
                              <thead>
                                <tr>
                                  <th scope="col">Correo Electrónico</th>
                                  <th scope="col">Contraseña</th>
                                  <th scope="col">Tipo de Usuario</th>
                                  <th scope="col">Editar</th>
                                  <th scope="col">Eliminar</th>
                                </tr>
                              </thead>
                              <tbody>
                                {usuarios.map((usuario) => (
                                  <tr key={usuario.id_us}>
                                    <td>{usuario.email}</td>
                                    <td>{usuario.password}</td>
                                    <td>{usuario.tipo_us}</td>
                                    <td
                                      style={{
                                        justifyContent: "center",
                                        gap: "10px",
                                      }}
                                    >
                                      <button
                                        onClick={() =>
                                          handleEditarUsuario(usuario.id_us)
                                        }
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "yellow",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faEdit} />
                                      </button>
                                    </td>
                                    <td
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        gap: "10px",
                                      }}
                                    >
                                      <button
                                        onClick={() =>
                                          handleEliminarUsuario(usuario.id_us)
                                        }
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "red",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faTrashAlt} />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          <div className="modal-footer">
                            <button
                              type="button"
                              className="btn btn-secondary"
                              onClick={toggleModal}
                            >
                              Cerrar
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Admin;
