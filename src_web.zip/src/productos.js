import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faEdit } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

function Productos() {
  const [modalVisible, setModalVisible] = useState(false);
  const [productos, setProductos] = useState([]);
  const [nuevoProducto, setNuevoProducto] = useState({
    grano: "",
    descripcion: "",
    precio: "",
    imag: ""
  });
  const [editandoProducto, setEditandoProducto] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn");
    if (loggedIn) {
      obtenerProductos();
    } else {
      navigate("/login", { state: { origen: "productos" } });
    }
  }, []);

  const obtenerProductos = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_get");
      const data = await response.json();
      setProductos(data);
    } catch (error) {
      console.error("Error al obtener los productos:", error);
    }
  };

  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  const handleEliminarProducto = async (id_prod) => {
    try {
      await fetch(`http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_delete?id_prod=${id_prod}`, {
        method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-HTTP-Method-Override": "DELETE"
          },
      });
      obtenerProductos();
      Swal.fire("¡Producto eliminado!", "El producto ha sido eliminado correctamente.", "success");
    } catch (error) {
      console.error("Error al eliminar el producto:", error);
    }
  };

  const handleChangeNuevoProducto = (e) => {
    setNuevoProducto({
      ...nuevoProducto,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmitNuevoProducto = async (e) => {
    e.preventDefault();
    if (!nuevoProducto.grano || !nuevoProducto.descripcion || !nuevoProducto.precio || !nuevoProducto.imag) {
      Swal.fire("¡Campos vacíos!", "Por favor completa todos los campos.", "error");
      return;
    }
  
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(nuevoProducto)
      });
  
      if (response.ok) {
        setNuevoProducto({
          grano: "",
          descripcion: "",
          precio: "",
          imag: ""
        });
        obtenerProductos();
        Swal.fire("¡Producto agregado!", "El producto ha sido agregado correctamente.", "success");
      } else {
        const errorMessage = await response.json();
        Swal.fire("Error", errorMessage.error, "error");
      }
    } catch (error) {
      console.error("Error al agregar el producto:", error);
      Swal.fire("Error", "Hubo un error al agregar el producto.", "error");
    }
  };
  

  const handleEditarProducto = (producto) => {
    setEditandoProducto(producto);
    setNuevoProducto({ ...producto });
  };
  
  const handleCancelarEdicion = () => {
    setEditandoProducto(null);
    setNuevoProducto({
      grano: "",
      descripcion: "",
      precio: "",
      imag: ""
    });
  };

  const handleActualizarProducto = async () => {
    if (JSON.stringify(nuevoProducto) === JSON.stringify(editandoProducto)) {
      Swal.fire("¡Sin cambios!", "No se han realizado cambios en la edición del producto.", "info");
      return;
    }
  
    try {
      const response = await fetch(`http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_put?id_prod=${editandoProducto.id_prod}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(nuevoProducto)
      });

      if (response.ok) {
        setEditandoProducto(null);
        obtenerProductos();
        Swal.fire("¡Producto actualizado!", "El producto ha sido actualizado correctamente.", "success");
      } else {
        const errorMessage = await response.json();
        Swal.fire("Error", errorMessage.error, "error");
      }
    } catch (error) {
      console.error("Error al actualizar el producto:", error);
      Swal.fire("Error", "Hubo un error al actualizar el producto.", "error");
    }
  };

  return (
    <section className="intro" style={{ height: "100%" }}>
      <div className="bg-image-vertical h-100" style={{ position: "relative", overflow: "hidden", backgroundRepeat: "no-repeat", backgroundPosition: "right center", backgroundSize: "auto 100%", backgroundColor: "#B2AFAF", backgroundImage: "url(https://img.freepik.com/fotos-premium/conjunto-diferentes-granos-enteros-frijoles-semillas-legumbres_73523-3388.jpg?w=1800)" }}>
        <div className="mask d-flex align-items-center h-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-lg-10">
                <div className="card" style={{ borderRadius: "1rem" }}>
                  <div className="card-body p-5">
                    <h2 className="mb-5 text-left">Productos</h2>
  
                    <form onSubmit={handleSubmitNuevoProducto}>
                      <div className="form-group">
                        <label htmlFor="grano">Grano</label>
                        <input
                          type="text"
                          className="form-control"
                          id="grano"
                          name="grano"
                          value={nuevoProducto.grano}
                          onChange={handleChangeNuevoProducto}
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="descripcion">Descripción</label>
                        <input
                          type="text"
                          className="form-control"
                          id="descripcion"
                          name="descripcion"
                          value={nuevoProducto.descripcion}
                          onChange={handleChangeNuevoProducto}
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="precio">Precio</label>
                        <input
                          type="number"
                          className="form-control"
                          id="precio"
                          name="precio"
                          value={nuevoProducto.precio}
                          onChange={handleChangeNuevoProducto}
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="imag">Imágen</label>
                        <input
                          type="text"
                          className="form-control"
                          id="imag"
                          name="imag"
                          value={nuevoProducto.imag}
                          onChange={handleChangeNuevoProducto}
                        />
                      </div>
                      <button type="submit" className="btn btn-primary mr-2">Agregar</button>
                      {editandoProducto && (
                        <>
                          <button type="button" className="btn btn-success mr-2" onClick={handleActualizarProducto}>Actualizar</button>
                          <button type="button" className="btn btn-secondary" onClick={handleCancelarEdicion}>Cancelar</button>
                        </>
                      )}
                    </form>
  
                    <button
                      className="btn btn-info mt-5"
                      onClick={toggleModal}
                    >
                      Mostrar Lista
                    </button>
  
                    {modalVisible && (
                      <div className="modal-dialog" role="document">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5 className="modal-title">Tabla de Productos</h5>
                          </div>
                          <div className="modal-body">
                            <table className="table table-bordered table-dark mt-5">
                              <thead>
                                <tr>
                                  <th scope="col">PRODUCTOS</th>
                                  <th scope="col">PRECIO</th>
                                  <th scope="col">DESCRIPCION</th>
                                  <th scope="col">OPCIONES</th>
                                </tr>
                              </thead>
                              <tbody>
                                {productos.map((producto) => (
                                  <tr key={producto.id_prod}>
                                    <th scope="row">{producto.grano}</th>
                                    <td>
                                      <span style={{ backgroundColor: "rgba(255, 255, 255, 0.8)", borderRadius: "5px", padding: "5px" }}>
                                        <span style={{ color: "green" }}>
                                          {producto.precio}
                                        </span>
                                      </span>
                                    </td>
                                    <td>{producto.descripcion}</td>
                                    <td style={{ display: "flex", justifyContent: "center", gap: "10px" }}>
                                      <button onClick={() => handleEliminarProducto(producto.id_prod)} style={{ border: "none", background: "none", color: "red", cursor: "pointer" }}>
                                        <FontAwesomeIcon icon={faTrashAlt} />
                                      </button>
                                      <button onClick={() => handleEditarProducto(producto)} style={{ border: "none", background: "none", color: "yellow", cursor: "pointer" }}>
                                        <FontAwesomeIcon icon={faEdit} />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" onClick={toggleModal}>
                              Cerrar
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Productos;
