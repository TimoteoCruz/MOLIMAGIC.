// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore";

function StartFirebase(){
  const firebaseConfig = {
  apiKey: "AIzaSyDGbEuNNVfEaGMleXkWeEz1wzECNSQLfwA",
  authDomain: "pmolimagic.firebaseapp.com",
  databaseURL: "https://pmolimagic-default-rtdb.firebaseio.com",
  projectId: "pmolimagic",
  storageBucket: "pmolimagic.appspot.com",
  messagingSenderId: "17595191983",
  appId: "1:17595191983:web:a8fedc6407c888175b3a5a",
  measurementId: "G-RLDF1YJWQ0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
return getFirestore(app);
}
export default StartFirebase;

