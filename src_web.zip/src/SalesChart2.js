import React, { useState, useEffect } from "react";
import Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more'; // Importar el módulo highcharts-more
import { collection, getDocs, query, where } from 'firebase/firestore';
import StartFirebase from "./firebase/config";
import DatePicker from "react-datepicker"; // Importar el componente DatePicker
import "react-datepicker/dist/react-datepicker.css"; // Estilos del DatePicker

// Agregar el módulo highcharts-more
HighchartsMore(Highcharts);

const db = StartFirebase(); 

const SalesChart2 = ({ isOpen }) => {
    const [branch, setBranch] = useState("Queretaro"); 
    const [startDate, setStartDate] = useState(null); 
    const [endDate, setEndDate] = useState(null); 
    const [fechasDisponibles, setFechasDisponibles] = useState([]);
    const [riceData, setRiceData] = useState([]); 
    const [coffeeData, setCoffeeData] = useState([]); 
    const [graphStartDate, setGraphStartDate] = useState(null); 
    const [graphEndDate, setGraphEndDate] = useState(null); 

    const handleBranchChange = (e) => {
        setBranch(e.target.value); 
    };

    const fetchAvailableDates = async () => {
        const temperaturaCollectionRef = collection(db, 'IOTsistem', branch, 'temperatura2');
        const querySnapshot = await getDocs(temperaturaCollectionRef);
        const dates = querySnapshot.docs.map(doc => doc.data().Fecha);
        // Eliminar duplicados y ordenar las fechas
        const uniqueDates = [...new Set(dates)].sort();
        setFechasDisponibles(uniqueDates);
    };

    const fetchData = async (startDate, endDate) => {
        const startDateString = startDate.toISOString().split('T')[0];
        const endDateString = endDate.toISOString().split('T')[0];

        setGraphStartDate(startDateString); 
        setGraphEndDate(endDateString);

        const temperaturaCollectionRef = collection(db, 'IOTsistem', branch, 'temperatura2');

        const riceQueryRef = query(temperaturaCollectionRef,
            where('Posicion', '==', '1'),
            where('Fecha', '>=', startDateString),
            where('Fecha', '<=', endDateString));
        const riceQuerySnapshot = await getDocs(riceQueryRef);
        const riceData = riceQuerySnapshot.docs.map(doc => ({
            temperatura: parseFloat(doc.data().Temperatura),
            humedad: parseFloat(doc.data().Humedad),
            hora: doc.data().Hora,
            fecha: doc.data().Fecha // Agregar el campo de fecha
        }));
        setRiceData(riceData);

        // Consulta para datos de café
        const coffeeQueryRef = query(temperaturaCollectionRef,
            where('Posicion', '==', '2'), // Cambiar posición a café
            where('Fecha', '>=', startDateString),
            where('Fecha', '<=', endDateString));
        const coffeeQuerySnapshot = await getDocs(coffeeQueryRef);
        const coffeeData = coffeeQuerySnapshot.docs.map(doc => ({
            temperatura: parseFloat(doc.data().Temperatura),
            humedad: parseFloat(doc.data().Humedad),
            hora: doc.data().Hora,
            fecha: doc.data().Fecha // Agregar el campo de fecha
        }));
        setCoffeeData(coffeeData);
    };

    useEffect(() => {
        fetchAvailableDates();
    }, [branch]); // Actualizar fechas disponibles cuando cambia la sucursal

    useEffect(() => {
        if (startDate !== null && endDate !== null) {
            fetchData(startDate, endDate);
        }
    }, [startDate, endDate, branch]); // Actualizar datos cuando cambian las fechas o la sucursal

    useEffect(() => {
        // Combina los datos de arroz y café para crear las series de la gráfica
        const tempSeries = [{
            name: 'Temperatura (Arroz)',
            type: 'line', // Cambiar a tipo línea
            data: riceData.map(entry => [entry.fecha + ' ' + entry.hora, entry.temperatura]), // Cambiar el formato de los datos
            color: '#FF5733', // Cambiar color
            marker: {
                radius: 4 // Cambiar tamaño de los marcadores
            }
        }, {
            name: 'Temperatura (Café)',
            type: 'line', // Cambiar a tipo línea
            data: coffeeData.map(entry => [entry.fecha + ' ' + entry.hora, entry.temperatura]), // Cambiar el formato de los datos
            color: '#337DFF', // Cambiar color
            marker: {
                radius: 4 // Cambiar tamaño de los marcadores
            }
        }];

        const humiditySeries = [{
            name: 'Humedad (Arroz)',
            type: 'line', // Cambiar a tipo línea
            data: riceData.map(entry => [entry.fecha + ' ' + entry.hora, entry.humedad]), // Cambiar el formato de los datos
            color: '#FF5733', // Cambiar color
            marker: {
                radius: 4 // Cambiar tamaño de los marcadores
            }
        }, {
            name: 'Humedad (Café)',
            type: 'line', // Cambiar a tipo línea
            data: coffeeData.map(entry => [entry.fecha + ' ' + entry.hora, entry.humedad]), // Cambiar el formato de los datos
            color: '#337DFF', // Cambiar color
            marker: {
                radius: 4 // Cambiar tamaño de los marcadores
            }
        }];

        Highcharts.chart('tempContainer', {
            chart: {
                type: 'line'
            },
            accessibility: {
                enabled: false
            },
            title: {
                text: 'Temperatura'
            },
            xAxis: {
                type: 'datetime',
                title: {
                    text: 'Fecha y Hora'
                }
            },
            yAxis: {
                title: {
                    text: 'Valor'
                }
            },
            series: tempSeries
        });

        Highcharts.chart('humidityContainer', {
            chart: {
                type: 'line'
            },
            accessibility: {
                enabled: false
            },
            title: {
                text: 'Humedad'
            },
            xAxis: {
                type: 'datetime',
                title: {
                    text: 'Fecha y Hora'
                }
            },
            yAxis: {
                title: {
                    text: 'Valor'
                }
            },
            series: humiditySeries
        });
    }, [riceData, coffeeData]); // Actualizar gráfica cuando cambian los datos de arroz o café

    return (
        <div className="container">
            <h1 className="text-center">Medición de Temperatura y Humedad</h1>
            <div className="form-group">
                <label htmlFor="startDate">Seleccione la fecha de inicio:</label>
                <DatePicker
                    selected={startDate}
                    onChange={date => setStartDate(date)}
                    dateFormat="yyyy-MM-dd"
                    className="form-control"
                />
            </div>
            <div className="form-group">
                <label htmlFor="endDate">Seleccione la fecha final:</label>
                <DatePicker
                    selected={endDate}
                    onChange={date => setEndDate(date)}
                    dateFormat="yyyy-MM-dd"
                    className="form-control"
                />
            </div>
            <div className="form-group">
                <label htmlFor="branch">Seleccione la sucursal:</label>
                <select id="branch" value={branch} onChange={handleBranchChange} className="form-control">
                    <option value={"Queretaro"}>Querétaro</option>
                    <option value={"CDMX"}>CDMX</option>
                    {/* Agrega más opciones según sea necesario */}
                </select>
            </div>
            <div id="tempContainer"></div>
            <p className="text-center">Fecha de inicio: {graphStartDate}, Fecha de fin: {graphEndDate}</p>
            <div id="humidityContainer"></div>
            <p className="text-center">Fecha de inicio: {graphStartDate}, Fecha de fin: {graphEndDate}</p>
        </div>
    );
};

export default SalesChart2;
