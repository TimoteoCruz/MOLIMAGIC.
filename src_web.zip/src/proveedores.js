import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faEdit } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";


function Proveedores() {
  const [proveedores, setProveedores] = useState([]);
  const [productos, setProductos] = useState([]);
  const [modalVisible, setModalVisible] = useState(false); // Estado para controlar la visibilidad del modal
  const [proveedorEditando, setProveedorEditando] = useState(null);
  const [nuevoProveedor, setNuevoProveedor] = useState({
    email: "",
    password: "",
    nombre: "",
    apaterno: "",
    amaterno: "", // Nuevo campo amaterno
    telefono: "",
    id_prod: "",
    peso: "",
    precio_por_kg: ""
  });

  useEffect(() => {
    if (proveedorEditando !== null) {
      setNuevoProveedor(proveedorEditando);
    } else {
      setNuevoProveedor({
        email: "",
        password: "",
        nombre: "",
        apaterno: "",
        amaterno: "",
        telefono: "",
        id_prod: "",
        peso: "",
        precio_por_kg: ""
      });
    }
  }, [proveedorEditando]);
  

  const navigate = useNavigate(); // Utiliza useNavigate en lugar de useHistory

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn");
    if (loggedIn) {
      obtenerProductos();
    } else {
      navigate("/login", { state: { origen: "proveedores" } }); // Utiliza navigate en lugar de history.push
    }
  }, []);

  // Obtén la ruta de origen de la redirección si existe
  const origenRedireccion = window.location.state?.origen;

  // Muestra una alerta si el usuario viene de la página de usuarios
  useEffect(() => {
    if (origenRedireccion === 'proveedores') {
      alert("Necesitas iniciar sesión para acceder a esta página.");
    }
  }, [origenRedireccion]);

  useEffect(() => {
    obtenerProveedores();
    obtenerProductos();
  }, []);

  const obtenerProveedores = () => {
    fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/proveedores_get")
      .then((response) => response.json())
      .then((data) => setProveedores(data))
      .catch((error) =>
        console.error("Error al obtener proveedores:", error)
      );
  };

  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  const obtenerProductos = () => {
    fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_get")
      .then((response) => response.json())
      .then((data) => setProductos(data))
      .catch((error) =>
        console.error("Error al obtener productos:", error)
      );
  };

  const handleEditarProveedor = (id) => {
    const proveedor = proveedores.find((prov) => prov.id_prov === id);
    setProveedorEditando(proveedor);
  };
  
  
  
  const actualizarProveedor = () => {
    fetch(`http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/proveedores_put`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...nuevoProveedor,
        id_prov: nuevoProveedor.id_prov,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setProveedorEditando(null);
        obtenerProveedores();
        Swal.fire("¡Proveedor actualizado!", "El proveedor ha sido actualizado correctamente.", "success");
      })
      .catch((error) => console.error("Error al actualizar proveedor:", error));
  };
  
  

const handleEliminarProveedor = (id) => {
  fetch(`http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/proveedores_delete?id=${id}`, {
    method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-HTTP-Method-Override": "DELETE"
          },
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      obtenerProveedores();
      Swal.fire("¡Proveedor eliminado!", "El proveedor ha sido eliminado correctamente.", "success");
    })
    .catch((error) => console.error("Error al eliminar proveedor:", error));
};


const handleAgregarProveedor = (e) => {
  e.preventDefault(); // Evitar que la página se recargue al enviar el formulario

  if (proveedorEditando) {
    actualizarProveedor();
  } else {
    fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/proveedores_post", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(nuevoProveedor),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setNuevoProveedor({/* resetear campos */});
        obtenerProveedores();
        Swal.fire("¡Proveedor Registrado!", "El proveedor ha sido registrado correctamente.", "success");
      })
      .catch((error) => console.error("Error al agregar proveedor:", error));
  }
};

  

  const handleChangeNuevoProveedor = (e) => {
    const { name, value } = e.target;
    setNuevoProveedor((prevProveedor) => ({
      ...prevProveedor,
      [name]: value,
    }));
  };

  return (
    <section className="intro" style={{ height: "100%" }}>
      <div
        className="bg-image-vertical h-100"
        style={{
          position: "relative",
          overflow: "hidden",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "right center",
          backgroundSize: "auto 100%",
          backgroundColor: "#B2AFAF",
          backgroundImage:
            "url(https://img.freepik.com/fotos-premium/conjunto-diferentes-granos-enteros-frijoles-semillas-legumbres_73523-3388.jpg?w=1800)",
        }}
      >
        <div className="mask d-flex align-items-center h-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-lg-10">
                <div className="card" style={{ borderRadius: "1rem" }}>
                  <div className="card-body p-5">
                    <h2 className="mb-5 text-left">Proveedores</h2>
  
                    <form onSubmit={handleAgregarProveedor}>
                      <div className="row">
                        <div className="col-md-6 mb-4">
                          <div className="row g-4">
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="email"
                                  className="form-control"
                                  name="email"
                                  value={nuevoProveedor.email}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="email"
                                >
                                  <span className="grain-text">
                                    Correo Electrónico
                                  </span>
                                </label>
                              </div>
                            </div>
                            {/* Otros campos */}
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="nombre"
                                  className="form-control"
                                  name="nombre"
                                  value={nuevoProveedor.nombre}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="nombre"
                                >
                                  <span className="grain-text">Nombre</span>
                                </label>
                              </div>
                            </div>
                            {/* Campo select para productos */}
                            <div className="col-12">
                              <div className="form-outline">
                                <select
                                  id="id_prod"
                                  className="form-select"
                                  name="id_prod"
                                  value={nuevoProveedor.id_prod}
                                  onChange={handleChangeNuevoProveedor}
                                >
                                  <option value="">Selecciona un producto</option>
                                  {productos.map((producto) => (
                                    <option key={producto.id_prod} value={producto.id_prod}>
                                      {producto.grano}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="peso"
                                  className="form-control"
                                  name="peso"
                                  value={nuevoProveedor.peso}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="peso"
                                >
                                  <span className="grain-text">Peso</span>
                                </label>
                              </div>
                            </div>
                            {/* Otros campos */}
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="precio_por_kg"
                                  className="form-control"
                                  name="precio_por_kg"
                                  value={nuevoProveedor.precio_por_kg}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="precio_por_kg"
                                >
                                  <span className="grain-text">
                                    Precio por kg
                                  </span>
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-6 mb-4">
                          <div className="row g-4">
                            {/* Otros campos */}
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="apaterno"
                                  className="form-control"
                                  name="apaterno"
                                  value={nuevoProveedor.apaterno}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="apaterno"
                                >
                                  <span className="grain-text">
                                    Apellido Paterno
                                  </span>
                                </label>
                              </div>
                            </div>
                            {/* Nuevo campo amaterno */}
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="amaterno"
                                  className="form-control"
                                  name="amaterno"
                                  value={nuevoProveedor.amaterno}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="amaterno"
                                >
                                  <span className="grain-text">
                                    Apellido Materno
                                  </span>
                                </label>
                              </div>
                            </div>
                            {/* Otros campos */}
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="telefono"
                                  className="form-control"
                                  name="telefono"
                                  value={nuevoProveedor.telefono}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="telefono"
                                >
                                  <span className="grain-text">
                                    Número Telefónico
                                  </span>
                                </label>
                              </div>
                            </div>
                            {/* Nuevo campo contraseña */}
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="password"
                                  id="password"
                                  className="form-control"
                                  name="password"
                                  value={nuevoProveedor.password}
                                  onChange={handleChangeNuevoProveedor}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="password"
                                >
                                  <span className="grain-text">
                                    Contraseña
                                  </span>
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
  
                      <button
                        type="submit"
                        className="btn btn-success btn-rounded btn-block"
                      >
                        {proveedorEditando ? "Actualizar" : "Guardar"}
                      </button>
                    </form>
  
                    <button
                      className="btn btn-info mb-3"
                      onClick={toggleModal}
                    >
                      Mostrar Lista
                    </button>
  
                    {/* Modal */}
                    {modalVisible && (
                      <div className="modal-dialog" role="document">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5 className="modal-title">Tabla de Proveedores</h5>
                          </div>
                          <div className="modal-body">
                            {/* Tabla */}
                            <table className="table table-bordered table-dark mt-5">
                              <thead>
                                <tr>
                                  <th scope="col">Correo Electrónico</th>
                                  <th scope="col">Nombre</th>
                                  <th scope="col">Apellido P</th>
                                  <th scope="col">Apellido M</th>
                                  <th scope="col">Cantidad Vendida</th>
                                  <th scope="col">PRECIO/KG</th>
                                  <th scope="col">Acciones</th>
                                </tr>
                              </thead>
                              <tbody>
                                {proveedores.map((proveedor) => (
                                  <tr key={proveedor.id_prov}>
                                    <td>{proveedor.email}</td>
                                    <td>{proveedor.nombre}</td>
                                    <td>{proveedor.apaterno}</td>
                                    <td>{proveedor.amaterno}</td>
                                    <td>{proveedor.peso} KG</td>
                                    <td>$ {proveedor.precio_por_kg}</td>
                                    <td
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        gap: "10px",
                                      }}
                                    >
                                      {/* Agrega los botones de editar y eliminar */}
                                      <button
                                        onClick={() =>
                                          handleEliminarProveedor(proveedor.id_prov)
                                        }
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "red",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faTrashAlt} />
                                      </button>
                                      <button
                                        onClick={() =>
                                          handleEditarProveedor(proveedor.id_prov)
                                        }
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "yellow",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faEdit} />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          <div className="modal-footer">
                            <button
                              type="button"
                              className="btn btn-secondary"
                              onClick={toggleModal}
                            >
                              Cerrar
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
  

}

export default Proveedores;
