import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom'; 
import { Dropdown } from 'react-bootstrap';
import SalesChart from './SalesChart';
import Productos from './productos';
import Proveedores from './proveedores';
import Usuarios from './usuarios';
import Admin from './admin';
import Ventas from './ventas.js';
import Mantenimiento from './mantenimiento';
import Inventario from './inventario';
import Sucursal from './sucursales.js';
import LoginForm from './login.js';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { googleLogout} from '@react-oauth/google';
function Sidebar({ isOpen }) {
  return (
    <nav id="sidebar" className={isOpen ? 'active' : ''}>
      <div className="sidebar-header">
        <h3>Moli Magic</h3>
      </div>
      <ul className="list-unstyled components">
        <li>
          <Link to="/"><i className="fas fa-home"></i> Inicio <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/mantenimiento"><i className="fas fa-wrench"></i>  Mantenimiento <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/proveedores"> <i className="fas fa-user-plus"></i>  Gestión Proveedores <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/productos"> <i className="fas fa-box-open"></i> Gestión Productos <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/inventario"> <i className="fas fa-box-open"></i> Gestión Inventario <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/sucursales"> <i className="fas fa-box-open"></i> Gestión Sucursales <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/usuarios"> <i className="fas fa-users-cog"></i> Gestión Clientes <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/admin"><i className="fas fa-cogs"></i> Gestión Administradores <i className="fas fa-angle-right"></i></Link>
        </li>
        <li>
          <Link to="/ventas"><i className="fas fa-cogs"></i> Gestión de Ventas <i className="fas fa-angle-right"></i></Link>
        </li>
      </ul>
    </nav>
  );
}

function App() {
  const [isOpen, setIsOpen] = useState(true);
  const [loggedInUserEmail, setLoggedInUserEmail] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const userEmail = sessionStorage.getItem('loggedInUserEmail');
    const loggedIn = sessionStorage.getItem('isLoggedIn');
    if (userEmail && loggedIn) {
      setLoggedInUserEmail(userEmail);
      setIsLoggedIn(true);
    }
  }, []);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const toggleLogout = () => {
    googleLogout();
    setUser(null); 
    sessionStorage.removeItem('loggedInUserEmail');
    sessionStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);
    
    window.location.reload();
    
    // Redireccionar a la página de inicio de sesión
    // window.location.href = "/login";  // Opcionalmente, puedes usar esto en lugar de recargar la página
  };

  return (
    <Router>
      <div className="wrapper">
        <div className={`header ${isOpen ? '' : 'sidebar-closed'}`}>
          <div className="toggle-button-left">
            <button className="btn btn-primary toggle-button" onClick={toggleSidebar}>
              <i className="fas fa-bars"></i>
            </button>
          </div>
          <div className="user-info-right">
            <div className="user-dropdown">
              <Dropdown>
                <Dropdown.Toggle variant="primary" id="dropdown-basic">
                  <i className="fas fa-user-circle fa-2x"></i>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item>{loggedInUserEmail}</Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={toggleLogout}>Cerrar sesión</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>
        </div>

        <Sidebar isOpen={isOpen} />
        <div id="content" className={isOpen ? '' : 'content-expanded'}>
          <div className="chart-container-shadow">
            <Routes>
              <Route path="/" element={<SalesChart />} />
              <Route path="/productos" element={<Productos />} />
              <Route path="/proveedores" element={<Proveedores />} />
              <Route path="/usuarios" element={<Usuarios setIsLoggedIn={setIsLoggedIn} />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/mantenimiento" element={<Mantenimiento />} />
              <Route path="/inventario" element={<Inventario />} />
              <Route path="/sucursales" element={<Sucursal />} />
              <Route path="/login" element={<LoginForm setIsLoggedIn={setIsLoggedIn} />} />
              <Route path="/ventas" element={<Ventas setIsLoggedIn={setIsLoggedIn} />} />
            </Routes>
          </div>
        </div>
      </div>
      <ToastContainer />
    </Router>
  );
}

export default App;
