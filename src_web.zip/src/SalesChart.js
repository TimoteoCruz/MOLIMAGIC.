import React, { useEffect, useState } from "react";
import Highcharts from "highcharts";
import { collection, getDocs } from "firebase/firestore";
import StartFirebase from "./firebase/config";
import "./estilos/styles.css";

const db = StartFirebase();

const SalesChart = ({ isOpen }) => {
  const [startDate, setStartDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [selectedWeeks, setSelectedWeeks] = useState([]);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [selectedMonths, setSelectedMonths] = useState([]); // Agregar estado para los meses seleccionados

  const handleStartDateChange = (e) => {
    setStartDate(e.target.value); // Actualizar la fecha de inicio seleccionada
  };

  const handleEndDateChange = (e) => {
    setEndDate(e.target.value); // Actualizar la fecha de fin seleccionada
  };

  const fetchData = async (sucursal) => {
    const pesoCollectionRef = collection(db, "IOTsistem", sucursal, "peso");
    const querySnapshot = await getDocs(pesoCollectionRef);

    const data = querySnapshot.docs
      .map((doc) => {
        const peso = parseFloat(doc.data().Peso);
        const hora = doc.data().Hora;
        const fecha = doc.data().Fecha;
        const sucursalName = sucursal === "Queretaro" ? "Querétaro" : "CDMX"; // Nombre de la sucursal
        const position = doc.data().Posicion; // Agregar la posición de los datos
        let producto = ""; // Variable para almacenar el producto correspondiente a la posición

        // Asignar producto según la posición
        if (position === "1") {
          producto = "Café";
        } else if (position === "2") {
          producto = "Arroz";
        } // Puedes continuar con más condiciones según sea necesario

        // Comprobar si la conversión fue exitosa
        if (!isNaN(peso) && hora && fecha) {
          return {
            peso,
            hora,
            fecha,
            sucursal: sucursalName,
            position,
            producto,
          }; // Incluir la posición y el producto en el objeto de datos
        } else {
          // Manejar el caso donde los datos no son válidos
          console.error("Datos no válidos:", doc.data());
          return null; // O algún otro valor que indique datos inválidos
        }
      })
      .filter(
        (entry) =>
          entry !== null && entry.fecha >= startDate && entry.fecha <= endDate
      ); // Filtrar las entradas nulas y las que están dentro del rango de fechas

    return data;
  };

  useEffect(() => {
    Promise.all([fetchData("Queretaro"), fetchData("CDMX")])
      .then(([queretaroData, cdmxData]) => {
        const combinedData = [...queretaroData, ...cdmxData];

        // Objeto para almacenar datos agrupados por mes
        const seriesDataByMonth = {};

        // Agrupar datos por mes
        combinedData.forEach((entry) => {
          const fecha = new Date(entry.fecha); // Convertir la fecha a objeto Date
          const formattedMonth = `${fecha.getMonth() + 1}`; // Obtener solo el número del mes
          if (!seriesDataByMonth[formattedMonth]) {
            seriesDataByMonth[formattedMonth] = [];
          }
          seriesDataByMonth[formattedMonth].push(entry);
        });
        console.log('Datos de Arroz:', combinedData.filter(entry => entry.producto === 'Arroz'));

        // Crear array de categorías para el eje X (meses) y ordenarlas de menor a mayor
        let months = Object.keys(seriesDataByMonth);
        months.sort((a, b) => new Date(a) - new Date(b));

        // Actualizar el estado de los meses seleccionados para el eje X
        setSelectedMonths(months);

        // Crear series para cada mes, filtrando los valores de peso entre 0 y 10
        // Crear series para cada fecha, filtrando los valores de peso entre 0 y 10
        const series = Object.keys(seriesDataByMonth).map((date) => ({
          name: date,
          data: seriesDataByMonth[date].map((entry) => ({
            x: new Date(entry.fecha).getTime(), // Convertir la fecha a milisegundos UNIX
            y: Math.min(Math.max(entry.peso, 0), 10), // Limitar el peso entre 0 y 10
            fecha: entry.fecha, // Agregar la fecha al objeto de datos
            sucursal: entry.sucursal, // Incluir el nombre de la sucursal en cada punto de datos
          })),
          stack: "peso", // Utilizar el nombre de la sucursal como stack
        }));

        Highcharts.chart("container1", {
          chart: {
            type: "column", // Cambiar el tipo de gráfico a columnas verticales
            events: {
              load: function () {
                this.series.forEach((series) => {
                  series.update(
                    {
                      showInLegend: false,
                      marker: {
                        enabled: false,
                      },
                    },
                    false
                  );
                });
                this.redraw();
              },
            },
          },
          yAxis: {
            title: {
              text: "Peso (kg)", // Descripción más clara del eje Y
            },
          },
          xAxis: {
            type: "datetime", // Configurar el tipo de eje X como fecha y hora
            title: {
              text: "Fecha", // Descripción más clara del eje X
            },
          },
          tooltip: {
            formatter: function () {
              let tooltipText = `<b>Fecha: ${Highcharts.dateFormat(
                "%e %b %Y",
                this.x
              )}</b><br>Peso: ${this.y}kg`;
              if (this.point.sucursal) {
                tooltipText += `<br>Sucursal: ${this.point.sucursal}`;
              }
              return tooltipText;
            },
          },
          plotOptions: {
            column: {
              pointPadding: 0.2,
              borderWidth: 0,
            },
          },
          series: series,
          colors: ["#7cb5ec", "#90ed7d"], // Colores diferentes para cada producto
        });
      })
      .catch((error) => {
        console.error("Error al obtener los datos:", error);
      });
  }, [startDate, endDate]);

  // Mostrar solo las fechas con datos en el eje X
  const xAxisCategories = selectedWeeks || [];

  return (
    <div>
      <div>
        <input type="date" value={startDate} onChange={handleStartDateChange} />
        <input type="date" value={endDate} onChange={handleEndDateChange} />
      </div>
      <div id="container1"></div>
      {selectedPoint && (
        <p>
          <b>{selectedPoint.series.name}</b>
          <br />
          Peso: {selectedPoint.y}kg
          <br />
          Sucursal: {selectedPoint.sucursal}
        </p>
      )}
      <div>
        <p>Productos:</p>
        <ul>
          <li>
            <span style={{ color: "#7cb5ec" }}>&#9632;</span> Café
          </li>
          <li>
            <span style={{ color: "#90ed7d" }}>&#9632;</span> Arroz
          </li>
          {/* Añade más elementos si hay más productos */}
        </ul>
      </div>
    </div>
  );
};

export default SalesChart;
