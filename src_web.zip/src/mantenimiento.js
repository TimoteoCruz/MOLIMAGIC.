import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import SalesChart2 from './SalesChart2';

function Mantenimiento() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Verificar si el usuario está autenticado al cargar el componente
    const loggedIn = sessionStorage.getItem('isLoggedIn');
    if (!loggedIn) {
      // Si el usuario no está autenticado, redirigirlo a la página de inicio de sesión
      navigate('/login');
    } else {
      setIsLoggedIn(true);
    }
  }, [navigate]);

  if (!isLoggedIn) {
    // No renderizar nada si el usuario no está autenticado
    return null;
  }

  return (
    <SalesChart2/>
  );
}

export default Mantenimiento;
