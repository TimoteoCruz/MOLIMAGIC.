import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faEdit } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';

function Inventario() {
  const [productos, setProductos] = useState([]);
  const [sucursales, setSucursales] = useState([]);
  const [inventario, setInventario] = useState([]);
  const [modalVisible, setModalVisible] = useState(false); // Estado para controlar la visibilidad del modal
  const [nuevoProducto, setNuevoProducto] = useState({
    stock: "",
    id_prod: "",
    id_suc: "",
    nombre_suc: ""
  });
  const [productoEditando, setProductoEditando] = useState(null);
  const [cambiosRealizados, setCambiosRealizados] = useState(false); // Variable para rastrear si se han realizado cambios

  const navigate = useNavigate();

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn");
    if (loggedIn) {
      obtenerProductos();
    } else {
      navigate("/login", { state: { origen: "inventario" } });
    }
  }, []);

  const origenRedireccion = window.location.state?.origen;

  useEffect(() => {
    if (origenRedireccion === 'inventario') {
      Swal.fire({
        icon: 'error',
        title: 'Acceso denegado',
        text: 'Necesitas iniciar sesión para acceder a esta página.'
      });
    }
  }, [origenRedireccion]);

  useEffect(() => {
    obtenerProductos();
    obtenerSucursales();
    obtenerInventario();
  }, []);

  const obtenerProductos = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_get");
      const data = await response.json();
      setProductos(data);
    } catch (error) {
      console.error("Error al obtener los productos:", error);
    }
  };

    const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  const obtenerSucursales = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/sucursal_get");
      const data = await response.json();
      setSucursales(data);
    } catch (error) {
      console.error("Error al obtener las sucursales:", error);
    }
  };

  const obtenerInventario = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/inventario_get");
      const data = await response.json();
      setInventario(data);
    } catch (error) {
      console.error("Error al obtener el inventario:", error);
    }
  };

  const handleEliminarProducto = async (id_inv) => {
    try {
      await fetch(`http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/inventario_delete?id_inv=${id_inv}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-HTTP-Method-Override": "DELETE"
        },
      });
      obtenerInventario();
      Swal.fire({
        icon: 'success',
        title: '¡Eliminado!',
        text: 'El producto ha sido eliminado correctamente.'
      });
    } catch (error) {
      console.error("Error al eliminar el producto:", error);
    }
  };

  const handleEditarProducto = (producto) => {
    setProductoEditando(producto);
    setNuevoProducto({
      stock: producto.stock,
      id_prod: producto.id_prod,
      id_suc: producto.id_suc,
      nombre_suc: producto.nombre_suc
    });
    // Al editar un producto, resetea la variable cambiosRealizados a false
    setCambiosRealizados(false);
  };

  const handleGuardarProducto = async (event) => {
    event.preventDefault();
    try {
      if (!nuevoProducto.stock || !nuevoProducto.id_prod || !nuevoProducto.id_suc) {
        Swal.fire({
          icon: 'error',
          title: 'Campos vacíos',
          text: 'Por favor, completa todos los campos para guardar el producto.'
        });
        return;
      }

      if (productoEditando) {
        await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/inventario_put", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ...productoEditando, ...nuevoProducto }),
        });
        if (cambiosRealizados) {
          Swal.fire({
            icon: 'success',
            title: '¡Actualizado!',
            text: 'El producto ha sido actualizado correctamente.'
          });
        } else {
          // Si no se realizaron cambios, muestra la alerta "Sin cambios"
          Swal.fire({
            icon: 'info',
            title: 'Sin cambios',
            text: 'No se han realizado cambios en la edición del producto.',
          });
        }
      } else {
        // Verificar si ya existe un producto con la misma sucursal en el inventario
        const verificarResponse = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/inventario_post?ent=verificar", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(nuevoProducto),
        });
        const verificarData = await verificarResponse.text(); // Obtener el texto de la respuesta
        
        if (verificarData.includes("Error")) {
          // Si la respuesta contiene "Error", muestra la alerta de duplicidad de producto
          Swal.fire({
            icon: 'error',
            title: 'Duplicidad de producto',
            text: verificarData, // Mostrar el mensaje de la respuesta
          });
          return;
        }

        await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/inventario_post", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(nuevoProducto),
        });
        Swal.fire({
          icon: 'success',
          title: '¡Registrado!',
          text: 'El producto ha sido registrado correctamente.'
        });
      }
      obtenerInventario();
      setProductoEditando(null);
      setNuevoProducto({
        stock: "",
        id_prod: "",
        id_suc: ""
      });
      setCambiosRealizados(false); // Resetea la variable cambiosRealizados después de guardar
    } catch (error) {
      console.error("Error al guardar el producto:", error);
    }
  };


  const handleChangeNuevoProducto = (event) => {
    const { name, value } = event.target;
    // Validar que en el campo de stock solo se ingresen números
    if (name === "stock" && isNaN(value)) {
      return;
    }
    setNuevoProducto((prevProducto) => ({
      ...prevProducto,
      [name]: value,
    }));
    // Al editar el campo, marca cambiosRealizados como true si hay cambios
    setCambiosRealizados(true);
  };

  return (
    <section className="intro" style={{ height: "100%" }}>
      <div
        className="bg-image-vertical h-100"
        style={{
          position: "relative",
          overflow: "hidden",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "right center",
          backgroundSize: "auto 100%",
          backgroundColor: "#B2AFAF",
          backgroundImage:
            "url(https://img.freepik.com/fotos-premium/conjunto-diferentes-granos-enteros-frijoles-semillas-legumbres_73523-3388.jpg?w=1800)",
        }}
      >
        <div className="mask d-flex align-items-center h-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-lg-10">
                <div className="card" style={{ borderRadius: "1rem" }}>
                  <div className="card-body p-5">
                    <h2 className="mb-5 text-left"> INVENTARIO</h2>
  
                    <form onSubmit={handleGuardarProducto}>
                      <div className="row">
                        <div className="col-md-6 mb-4">
                          <div className="row g-4">
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="formAmount"
                                  className="form-control"
                                  name="stock"
                                  value={nuevoProducto.stock}
                                  onChange={handleChangeNuevoProducto}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="formGrainType"
                                >
                                  <span className="grain-text">Stock</span>
                                </label>{" "}
                              </div>
                            </div>
                            <div className="col-12">
                              <div className="form-outline">
                                <select
                                  id="id_prod"
                                  className="form-select"
                                  name="id_prod"
                                  value={nuevoProducto.id_prod}
                                  onChange={handleChangeNuevoProducto}
                                >
                                  <option value="">Selecciona un producto</option>
                                  {productos.map((producto) => (
                                    <option key={producto.id_prod} value={producto.id_prod}>
                                      {producto.grano}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-6 mb-4">
                          <div className="row g-4">
                            <div className="col-12">
                              <div className="form-outline">
                                <select
                                  id="id_suc"
                                  className="form-select"
                                  name="id_suc"
                                  value={nuevoProducto.id_suc}
                                  onChange={handleChangeNuevoProducto}
                                >
                                  <option value="">Selecciona una sucursal</option>
                                  {sucursales.map((sucursal) => (
                                    <option key={sucursal.id_suc} value={sucursal.id_suc}>
                                      {sucursal.nombre_suc}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
  
                      <button
                        type="submit"
                        className="btn btn-success btn-rounded btn-block"
                      >
                        Guardar{" "}
                      </button>
                    </form>
  
                    {/* Botón para mostrar el modal */}
                    <button
                      className="btn btn-info mt-5"
                      onClick={toggleModal}
                    >
                      Mostrar Lista
                    </button>
  
                    {/* Modal */}
                    {modalVisible && (
                      <div className="modal-dialog" role="document">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5 className="modal-title">Tabla de Sucursales</h5>
                          </div>
                          <div className="modal-body">
                            {/* Tabla */}
                            <table className="table table-bordered table-dark mt-5">
                              <thead>
                                <tr>
                                  <th scope="col">STOCK</th>
                                  <th scope="col">PRODUCTO</th>
                                  <th scope="col">SUCURSAL</th>
                                  <th scope="col">OPCIONES</th>
                                </tr>
                              </thead>
                              <tbody>
                                {inventario.map((producto) => (
                                  <tr key={producto.id_inv}>
                                    <td>{producto.stock}</td>
                                    <td>{producto.grano}</td>
                                    <td>{producto.nombre_suc}</td>
                                    <td
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        gap: "10px",
                                      }}
                                    >
                                      <button
                                        onClick={() => handleEliminarProducto(producto.id_inv)}
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "red",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faTrashAlt} />
                                      </button>
                                      <button
                                        onClick={() => handleEditarProducto(producto)}
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "yellow",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faEdit} />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          <div className="modal-footer">
                            <button
                              type="button"
                              className="btn btn-secondary"
                              onClick={toggleModal}
                            >
                              Cerrar
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
  
}

export default Inventario;
