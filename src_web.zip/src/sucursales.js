import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faEdit, faEye } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { GoogleMap, Marker, InfoWindow } from "@react-google-maps/api";

function Sucursal() {
  const [sucursales, setSucursales] = useState([]);
  const [nuevaSucursal, setNuevaSucursal] = useState("");
  const [sucursalEditando, setSucursalEditando] = useState(null);
  const [idMaquina, setIdMaquina] = useState("");
  const [coordenadas, setCoordenadas] = useState({ lat: 20.5937, lng: -100.392 });
  const [modalVisible, setModalVisible] = useState(false);
  const [infoWindowData, setInfoWindowData] = useState(null); // Estado para manejar la ventana de información
  const navigate = useNavigate();

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn");
    if (loggedIn) {
      obtenerSucursales();
    } else {
      navigate("/login", { state: { origen: "inventario" } });
    }
  }, []);

  const obtenerSucursales = async () => {
    try {
      const response = await fetch(
        "http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/sucursal_get"
      );
      const data = await response.json();
      setSucursales(data);
    } catch (error) {
      console.error("Error al obtener las sucursales:", error);
      Swal.fire({
        icon: "error",
        title: "Error",
        text:
          "Hubo un error al obtener las sucursales. Por favor, inténtalo de nuevo más tarde.",
      });
    }
  };

  const handleEliminarSucursal = async (id_suc) => {
    try {
      await fetch(
        `http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/sucursal_delete?id_suc=${id_suc}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-HTTP-Method-Override": "DELETE",
          },
        }
      );
      obtenerSucursales();
      Swal.fire({
        icon: "success",
        title: "¡Eliminado!",
        text: "La sucursal ha sido eliminada correctamente.",
      });
    } catch (error) {
      console.error("Error al eliminar la sucursal:", error);
      Swal.fire({
        icon: "error",
        title: "Error",
        text:
          "Hubo un error al eliminar la sucursal. Por favor, inténtalo de nuevo más tarde.",
      });
    }
  };

  const handleEditarSucursal = (id_suc, sucursal) => {
    if (id_suc) {
      setSucursalEditando(sucursal);
      setNuevaSucursal(sucursal.nombre_suc);
      setIdMaquina(sucursal.id_maquina);
      const coordenadasArray = sucursal.coordenadas
        ? sucursal.coordenadas.split(",")
        : [];
      const [lat, lng] = coordenadasArray.map((coord) => parseFloat(coord));
      setCoordenadas({ lat, lng });
    } else {
      console.error("ID de la sucursal no definido");
    }
  };

  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  const handleGuardarSucursal = async (event) => {
    event.preventDefault();
    try {
      if (!nuevaSucursal.trim()) {
        Swal.fire({
          icon: "error",
          title: "Campo vacío",
          text: "Por favor, ingresa el nombre de la sucursal.",
        });
        return;
      }

      const nuevaSucursalData = {
        nombre_suc: nuevaSucursal,
        id_maquina: idMaquina,
        coordenadas: `${coordenadas.lat},${coordenadas.lng}`,
      };

      let url =
        "http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/sucursal_post";
      let method = "POST";
      if (sucursalEditando) {
        url = `http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/sucursal_put?id=${sucursalEditando.id_suc}`;
        method = "POST";
      }

      await fetch(url, {
        method: method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(nuevaSucursalData),
      });

      Swal.fire({
        icon: "success",
        title: sucursalEditando ? "¡Actualizado!" : "¡Registrado!",
        text: `La sucursal ha sido ${
          sucursalEditando ? "actualizada" : "registrada"
        } correctamente.`,
      });

      obtenerSucursales();
      setNuevaSucursal("");
      setIdMaquina("");
      setCoordenadas({ lat: 20.5937, lng: -100.392 });
      setSucursalEditando(null);
    } catch (error) {
      console.error("Error al guardar la sucursal:", error);
      Swal.fire({
        icon: "error",
        title: "Error",
        text:
          "Hubo un error al guardar la sucursal. Por favor, inténtalo de nuevo más tarde.",
      });
    }
  };

  const handleMarkerClick = (sucursal) => {
    setInfoWindowData(sucursal);
  };

  return (
    <section className="intro" style={{ height: "100%" }}>
      <div className="bg-image-vertical h-100">
        <div className="mask d-flex align-items-center h-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-lg-10">
                <div className="card" style={{ borderRadius: "1rem" }}>
                  <div className="card-body p-5">
                    <h2 className="mb-5 text-left"> SUCURSAL</h2>

                    <form onSubmit={handleGuardarSucursal}>
                      <div className="row">
                        <div className="col-md-6 mb-4">
                          <div className="row g-4">
                            <div className="col-12">
                              <div className="form-outline">
                                <input
                                  type="text"
                                  id="formAmount"
                                  className="form-control"
                                  name="nombre_suc"
                                  value={nuevaSucursal}
                                  onChange={(e) => setNuevaSucursal(e.target.value)}
                                />
                                <label
                                  className="form-label gray-label btn-grain-type"
                                  htmlFor="formGrainType"
                                >
                                  <span className="grain-text">
                                    Nombre de la Sucursal
                                  </span>
                                </label>{" "}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-6 mb-4">
                          <div className="form-outline">
                            <input
                              type="text"
                              id="formMaquina"
                              className="form-control"
                              name="id_maquina"
                              value={idMaquina}
                              onChange={(e) => setIdMaquina(e.target.value)}
                            />
                            <label
                              className="form-label gray-label btn-grain-type"
                              htmlFor="formMaquina"
                            >
                              <span className="grain-text">ID Máquina</span>
                            </label>{" "}
                          </div>
                        </div>
                      </div>

                      <div style={{ height: "500px", width: "100%" }}>
                        <GoogleMap
                          mapContainerStyle={{
                            height: "100%",
                            width: "100%",
                          }}
                          center={coordenadas}
                          zoom={12}
                          onClick={(event) => {
                            setCoordenadas({
                              lat: event.latLng.lat(),
                              lng: event.latLng.lng(),
                            });
                          }}
                        >
                          {sucursales.map((sucursal) => (
                            <Marker
                              key={sucursal.id_suc}
                              position={{
                                lat: parseFloat(
                                  sucursal.coordenadas.split(",")[0]
                                ),
                                lng: parseFloat(
                                  sucursal.coordenadas.split(",")[1]
                                ),
                              }}
                              onClick={() => handleMarkerClick(sucursal)}
                            />
                          ))}
                          {infoWindowData && (
                            <InfoWindow
                              position={{
                                lat: parseFloat(
                                  infoWindowData.coordenadas.split(",")[0]
                                ),
                                lng: parseFloat(
                                  infoWindowData.coordenadas.split(",")[1]
                                ),
                              }}
                              onCloseClick={() => setInfoWindowData(null)}
                            >
                              <div>
                              <h3>Sucursal Moli Magic</h3>
                                <h4>{infoWindowData.nombre_suc}</h4>
                              </div>
                            </InfoWindow>
                          )}
                        </GoogleMap>
                      </div>

                      <button
                        type="submit"
                        className="btn btn-success btn-rounded btn-block mt-4"
                      >
                        Guardar
                      </button>
                    </form>

                    <button
                      className="btn btn-info mt-5"
                      onClick={toggleModal}
                    >
                      Mostrar Lista
                    </button>

                    {modalVisible && (
                      <div className="modal-dialog" role="document">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5 className="modal-title">Tabla de Sucursales</h5>
                          </div>
                          <div className="modal-body">
                            <table className="table table-bordered table-dark mt-5">
                              <thead>
                                <tr>
                                  <th scope="col">Nombre de la Sucursal</th>
                                  <th scope="col">ID Maquina</th>
                                  <th scope="col">OPCIONES</th>
                                </tr>
                              </thead>
                              <tbody>
                                {sucursales.map((sucursal) => (
                                  <tr key={sucursal.id_suc}>
                                    <td>{sucursal.nombre_suc}</td>
                                    <td>{sucursal.id_maquina}</td>
                                    <td
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        gap: "10px",
                                      }}
                                    >
                                      <button
                                        onClick={() =>
                                          handleEliminarSucursal(
                                            sucursal.id_suc
                                          )
                                        }
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "red",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon
                                          icon={faTrashAlt}
                                        />
                                      </button>
                                      <button
                                        onClick={() =>
                                          handleEditarSucursal(
                                            sucursal.id_suc,
                                            sucursal
                                          )
                                        }
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "yellow",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faEdit} />
                                      </button>
                                      <button
                                        onClick={() => handleMarkerClick(sucursal)}
                                        style={{
                                          border: "none",
                                          background: "none",
                                          color: "blue",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faEye} />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          <div className="modal-footer">
                            <button
                              type="button"
                              className="btn btn-secondary"
                              onClick={toggleModal}
                            >
                              Cerrar
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Sucursal;
