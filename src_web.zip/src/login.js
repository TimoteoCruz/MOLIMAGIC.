import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLeaf } from "@fortawesome/free-solid-svg-icons";
import { MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBIcon, MDBInput } from "mdb-react-ui-kit";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Button from 'react-bootstrap/Button';
import Alert from 'react-bootstrap/Alert';
import { useNavigate } from 'react-router-dom';
import {useGoogleLogin } from '@react-oauth/google';
import { faGoogle } from '@fortawesome/free-brands-svg-icons';

function LoginForm({ setIsLoggedIn }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showAlert, setShowAlert] = useState(false); // Estado para mostrar la alerta
  const navigate = useNavigate(); // Utiliza useNavigate para la redirección
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (user) {
        fetch(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`, {
            headers: {
                Authorization: `Bearer ${user.access_token}`,
                Accept: 'application/json'
            }
        })
        .then(res => res.json())
        sessionStorage.setItem('isLoggedIn', true);
          toast.success(email.message);
          setShowAlert(true);
          setUser(email);
          navigate('/');
    }
}, [user]);

  const handleLogin = async () => {
    try {
      const formData = new URLSearchParams();
      formData.append('email', email);
      formData.append('password', password);

      const response = await fetch('http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData.toString()
      });
      const data = await response.json();
      
      if (data.status === 'success') {
        sessionStorage.setItem('isLoggedIn', true);
        sessionStorage.setItem('loggedInUserEmail', email);
        toast.success(data.message);
        setShowAlert(true);

      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Ha ocurrido un error al iniciar sesión.');
    }
  };

  // Muestra una alerta si el usuario vuelve desde la página de usuarios
  useEffect(() => {
    if (navigate.state?.origen === 'usuarios') {
      setShowAlert(true);
    }
  }, []);

  const handleAlertClose = () => {
    setShowAlert(false); // Cerrar la alerta
  };

  const login = useGoogleLogin({
    onSuccess: (codeResponse) => setUser(codeResponse),
    onError: (error) => console.log('Login Failed:', error)
});


  return (
    <MDBContainer className="my-5">
      <MDBCard>
        <MDBRow className="g-0">
          <MDBCol md="4">
            <MDBCardImage
              src="https://th.bing.com/th/id/OIP.Dz6C5YAIFDinAEA-eNtWogHaLH?w=1170&h=1755&rs=1&pid=ImgDetMain"
              alt="login form"
              className="rounded-start w-100"
            />
          </MDBCol>

          <MDBCol md="6">
            <MDBCardBody className="d-flex flex-column">
              <div className="d-flex flex-row mt-2">
                <MDBIcon>
                  <FontAwesomeIcon
                    icon={faLeaf}
                    style={{
                      fontSize: "3em",
                      marginRight: "0.5em",
                      color: "green",
                    }}
                  />
                </MDBIcon>
                <span className="h1 fw-bold mb-0">MoliMagic</span>
              </div>

              <h5
                className="fw-normal my-4 pb-3"
                style={{ letterSpacing: "1px" }}
              >
                Inicia Sesión En MoliMagic
              </h5>

              <MDBInput
                wrapperClass="mb-4"
                label="Correo Electronico"
                id="formControlEmail"
                type="email"
                size="lg"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <MDBInput
                wrapperClass="mb-4"
                label="Contraseña"
                id="formControlPassword"
                type="password"
                size="lg"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              <Button variant="dark" className="mb-4 px-5" size="lg" onClick={handleLogin}>
                Entrar
              </Button>
              <Button
                    variant="outline-primary"
                    onClick={login}>
                    <FontAwesomeIcon icon={faGoogle} className="fa-3x mx-2" />
                    Entrar con Google
                </Button>
              <div className="d-flex flex-row justify-content-start">
                <a href="#!" className="small text-muted me-1">
                  Terminos de Uso.
                </a>
                <a href="#!" className="small text-muted">
                  Politicas de Privacidad
                </a>
              </div>
            </MDBCardBody>
          </MDBCol>
        </MDBRow>
      </MDBCard>

      <ToastContainer />
      
    </MDBContainer>
  );
}

export default LoginForm;
