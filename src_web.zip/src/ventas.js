import React, { useState, useEffect, useRef } from "react";
import Chart from "chart.js/auto";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { Modal } from 'react-bootstrap';
import Confetti from 'react-confetti';
import { Chart as ChartJS } from 'chart.js';
import 'chartjs-adapter-date-fns';
import Highcharts from 'highcharts';

function Ventas() {
  const [ventas, setVentas] = useState([]);
  const [fechaInicio, setFechaInicio] = useState("");
  const [fechaFin, setFechaFin] = useState("");
  const [producto, setProducto] = useState("");
  const [sucursal, setSucursal] = useState("");
  const [productos, setProductos] = useState([]);
  const [sucursales, setSucursales] = useState([]);
  const [productoMasVendidoDia, setProductoMasVendidoDia] = useState("");
  const [granoProductoDia, setGranoProductoDia] = useState(""); 
  const [showModal, setShowModal] = useState(false);

  const [productoMasVendido, setProductoMasVendido] = useState({
    id_prod: "",
    grano: "",
    descripcion: "",
    total_ventas: "",
    fech_ven: ""
  });
  const navigate = useNavigate();
  const chartRef = useRef(null);

  useEffect(() => {
    Highcharts.setOptions({
        colors: ['rgba(5,141,199,0.5)', 'rgba(80,180,50,0.5)', 'rgba(237,86,27,0.5)']
    });

    const series = [{
        name: 'Arroz',
        id: 'arroz',
        marker: {
            symbol: 'circle'
        }
    },
    {
        name: 'Café',
        id: 'cafe',
        marker: {
            symbol: 'triangle'
        }
    }];

    async function getData() {
        // Aquí obtienes tus datos de ventas y peso (kg)
        // Puedes reemplazar este bloque con tu lógica para obtener los datos reales
        return [
            { sport: 'arroz', height: 2.3, weight: 100 },
            { sport: 'arroz', height: 2.1, weight: 80 },
            { sport: 'cafe', height: 1.8, weight: 90 },
            { sport: 'cafe', height: 1.7, weight: 85 },
            // Agrega más datos según sea necesario
        ];
    }

    getData().then(data => {
        const getData = sportName => {
            const temp = [];
            data.forEach(elm => {
                if (elm.sport === sportName && elm.weight > 0 && elm.height > 0) {
                    temp.push([elm.weight, elm.height]);
                }
            });
            return temp;
        };
        series.forEach(s => {
            s.data = getData(s.id);
        });

        Highcharts.chart('container', {
            chart: {
                type: 'scatter',
                zoomType: 'xy'
            },
            title: {
                text: 'Ventas vs Peso',
                align: 'left'
            },
            xAxis: {
                title: {
                    text: 'Ventas'
                }
            },
            yAxis: {
                title: {
                    text: 'Peso (kg)'
                },
                labels: {
                    format: '{value} kg'
                }
            },
            legend: {
                enabled: true
            },
            tooltip: {
                pointFormat: 'Ventas: {point.x} <br/> Peso: {point.y} kg'
            },
            series
        });
    });
  }, []);

  useEffect(() => {
    const loggedIn = sessionStorage.getItem("isLoggedIn");
    if (loggedIn) {
      obtenerProductos();
      obtenerSucursales();
    } else {
      navigate("/login", { state: { origen: "ventas" } });
    }
  }, []);

  useEffect(() => {
    if (ventas.length === 0) return;

    const ctx = chartRef.current.getContext("2d");

    // Verificar si ya hay un gráfico creado y destruirlo si es así
    if (chartRef.current.chart) {
      chartRef.current.chart.destroy();
    }

    // Crear objeto de conteo para cada combinación de sucursal y grano
    const conteo = {};
    ventas.forEach(venta => {
      const clave = `${venta["Sucursal"]}_${venta["Producto Vendido"]}`;
      if (conteo[clave]) {
        conteo[clave]++;
      } else {
        conteo[clave] = 1;
      }
    });

    const maxConteo = Math.max(...Object.values(conteo)); // Calculamos el máximo conteo de ventas

    const data = {
      datasets: Object.keys(conteo).map(clave => ({
        label: clave,
        data: ventas
          .filter(venta => venta["Sucursal"] + "_" + venta["Producto Vendido"] === clave)
          .map(venta => ({
            x: new Date(venta["Fecha de Venta"]).getTime(),
            y:  venta["Cantidad Vendida"],
          })),
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1
      }))
    };

    const options = {
      scales: {
        x: {
          type: 'time',
          time: {
            unit: 'day'
          },
          title: {
            display: true,
            text: 'Fecha de Venta'
          }
        },
        y: {
          title: {
            display: true,
            text: 'Cantidad Vendida'
          }
        }
      }
    };

    // Crear el nuevo gráfico
    chartRef.current.chart = new Chart(ctx, {
      type: 'bubble',
      data: data,
      options: options
    });
  }, [ventas]);

  const obtenerVentas = async () => {
    if (!fechaInicio || !fechaFin || !producto) {
      Swal.fire({
        icon: "error",
        title: "¡Error!",
        text: "Por favor, complete todos los campos para realizar la búsqueda.",
      });
      return;
    }

    try {
      const response = await fetch(
        `http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/obtenerReporteVentas?fechaInicio=${fechaInicio}&fechaFin=${fechaFin}&producto=${producto}&sucursal=${sucursal}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const data = await response.json();

      if (data[0]?.Mensaje === 'No hay ventas') {
        setVentas([]);
        Swal.fire({
          icon: "warning",
          title: "Sin resultados",
          text: "No hay ventas para el producto en la sucursal especificada.",
        });
      } else if (data.length === 0) {
        setVentas([]);
        Swal.fire({
          icon: "warning",
          title: "Sin resultados",
          text: "No se encontraron ventas para los criterios especificados.",
        });
      } else {
        setVentas(data);
        obtenerProductoMasVendido();
        Swal.fire({
          icon: "success",
          title: "¡Búsqueda completa!",
          text: "Se encontraron ventas.",
        });
      }
    } catch (error) {
      console.error("Error al obtener ventas:", error);
    }
  };

  const obtenerProductoMasVendido = async () => {
    const fechaHoy = new Date();
    const fechaFormateada = fechaHoy.toISOString().split('T')[0];
  
    if (!sucursal) {
      console.error("Error: Sucursal no especificada.");
      return;
    }
  
    try {
      const response = await fetch(
        `http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/obtenerProductoMasVendido?fecha=${fechaFormateada}&sucursal_nombre=${sucursal}`
      );
      const data = await response.json();
  
      if (data.error) {
        console.error("Error al obtener el producto más vendido:", data.error);
      } else {
        if (data.grano) {
          console.log("Producto más vendido del día:", data.grano);
          setProductoMasVendidoDia(data.grano);
          setGranoProductoDia(data.grano);
          setProductoMasVendido({
            id_prod: data.id_prod,
            grano: data.grano,
            descripcion: data.descripcion,
            total_ventas: data.total_ventas,
            fech_ven: data.fech_ven
          });
          setShowModal(true);
        } else {
          console.error("No se encontró ningún producto del día");
        }
      }
    } catch (error) {
      console.error("Error al obtener producto más vendido del día:", error);
    }
  };

  const obtenerProductos = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/productos_get");
      const data = await response.json();
      setProductos(data);
    } catch (error) {
      console.error("Error al obtener productos:", error);
    }
  };

  const obtenerSucursales = async () => {
    try {
      const response = await fetch("http://dtai.uteq.edu.mx/~timcru213/apisweb/webservice/back/sucursal_get");
      const data = await response.json();
      setSucursales(data);
    } catch (error) {
      console.error("Error al obtener sucursales:", error);
    }
  };

  return (
    <section className="intro" style={{ height: "100%" }}>
      <div
        className="bg-image-vertical h-100"
        style={{
          position: "relative",
          overflow: "hidden",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "right center",
          backgroundSize: "auto 100%",
          backgroundColor: "#B2AFAF",
          backgroundImage:
            "url(https://img.freepik.com/fotos-premium/conjunto-diferentes-granos-enteros-frijoles-semillas-legumbres_73523-3388.jpg?w=1800)",
        }}
      >
        <div className="mask d-flex align-items-center h-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-lg-10">
                <div className="card" style={{ borderRadius: "1rem" }}>
                  <div className="card-body p-5">
                    <h2 className="mb-5 text-left">Reporte de Ventas</h2>
                    <div className="mb-4">
                      <h4>Parámetros de Búsqueda</h4>
                      <div className="form-row">
                        <div className="col">
                          <input
                            type="date"
                            className="form-control"
                            placeholder="Fecha de Inicio"
                            value={fechaInicio}
                            onChange={(e) => setFechaInicio(e.target.value)}
                          />
                        </div>
                        <div className="col">
                          <input
                            type="date"
                            className="form-control"
                            placeholder="Fecha de Fin"
                            value={fechaFin}
                            onChange={(e) => setFechaFin(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="form-row mt-3">
                        <div className="col">
                          <select
                            className="form-control"
                            value={producto}
                            onChange={(e) => setProducto(e.target.value)}
                          >
                            <option value="">Selecciona un producto</option>
                            {productos.map((producto) => (
                              <option key={producto.id_prod} value={producto.grano}>
                                {producto.grano}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col">
                          <button
                            type="button"
                            className="btn btn-primary mr-2"
                            onClick={obtenerVentas}
                          >
                            Buscar
                          </button>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3>Ventas</h3>
                      <div className="table-responsive">
                        <table className="table table-bordered table-striped">
                          <thead className="thead-dark">
                            <tr>
                              <th>ID Venta</th>
                              <th>Fecha de Venta</th>
                              <th>Cantidad Vendida</th>
                              <th>Precio Unitario</th>
                              <th>Producto Vendido</th>
                              <th>Sucursal</th>
                              <th>Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            {ventas.map((venta, index) => (
                              <tr key={index}>
                                <td>{venta["ID Venta"]}</td>
                                <td>{venta["Fecha de Venta"]}</td>
                                <td>{venta["Cantidad Vendida"]}</td>
                                <td>{venta["Precio Unitario"]}</td>
                                <td>{venta["Producto Vendido"]}</td>
                                <td>{venta["Sucursal"]}</td>
                                <td>{venta["Total"]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="modal-wrapper">
        <Modal show={showModal} onHide={() => setShowModal(false)} animation={true}>
          <Modal.Header closeButton>
            <Modal.Title>Producto del Día</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p><strong>Grano:</strong> {granoProductoDia}</p>
            <p><strong>ID:</strong> {productoMasVendido.id_prod}</p>
            <p><strong>Descripción:</strong> {productoMasVendido.descripcion}</p>
            <p><strong>Total de Ventas:</strong> {productoMasVendido.total_ventas}</p>
            <p><strong>Fecha de Venta:</strong> {productoMasVendido.fech_ven}</p>
            <Confetti numberOfPieces={400} />
          </Modal.Body>
        </Modal>
      </div>
      <div className="sucursal-wrapper">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-lg-10">
              <div className="card" style={{ borderRadius: "1rem" }}>
                <div className="card-body p-5">
                  <h2 className="mb-5 text-left">Seleccionar Sucursal</h2>
                  <div className="mb-4">
                    <select
                      className="form-control"
                      value={sucursal}
                      onChange={(e) => setSucursal(e.target.value)}
                    >
                      <option value="">Selecciona una sucursal</option>
                      {sucursales.map((sucursal) => (
                        <option key={sucursal.id_suc} value={sucursal.nombre_suc}>
                          {sucursal.nombre_suc}
                        </option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="button"
                    className="btn btn-success mr-2"
                    onClick={obtenerProductoMasVendido}
                  >
                    Descubrir Producto del Día
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="chart-wrapper">
      <div id="container" style={{ height: "400px" }}></div>
      </div>
    </section>
  );
}

export default Ventas;
