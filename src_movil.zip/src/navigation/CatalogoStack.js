import React, { useState, useEffect } from 'react';
import { ImageBackground, View, StyleSheet, Text, TouchableOpacity, TextInput, Image, ScrollView, RefreshControl, Alert, Linking } from 'react-native';
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Picker } from "@react-native-picker/picker";
import { vista } from "../utils/nombreVista";
import Toast from 'react-native-toast-message';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CommonActions } from '@react-navigation/native';


const Stack = createNativeStackNavigator();

const styles = StyleSheet.create({
  card: {
    width: '44%', 
    margin: 10,
    marginBottom: 40,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 5,
    backgroundColor: 'white',
  },
  image: {
    width: '100%',
    height: 200,
    justifyContent: 'flex-end',
  },
  title: {
    fontSize: 24,
    color: 'black',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 5,
  },
  price: {
    fontSize: 20,
    color: 'black',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 10,
  },
  description: {
    fontSize: 16,
    color: 'black',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 4,
  },
  button: {
    backgroundColor: '#735634',
    padding: 10,
    alignItems: 'center',
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    paddingBottom: -20, // Ajusta este valor para cambiar la distancia entre el texto y el picker
    alignItems: 'center',
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 5,
    paddingHorizontal: 10,
    flex: 1,
  },
  userDataContainer: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 5,
    borderRadius: 5,
  },
  userDataText: {
    fontSize: 16,
    color: 'black',
  },
  logoutButton: {
    position: 'absolute',
    top: 10,
    left: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 5,
    borderRadius: 5,
  },
  logoutButtonText: {
    fontSize: 16,
    color: 'white',
  },
  pickerContainer: {
    width: 100, // Modifica el ancho según tus necesidades
    marginTop: 10, // Ajusta este valor para cambiar la distancia entre el selector y la tarjeta
    backgroundColor: 'white',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  picker: {
    height: 35, // Modifica la altura según tus necesidades
    paddingHorizontal: 10,
  },
});

const styles2 = StyleSheet.create({
  sucursalContainer: {
    alignItems: 'center',
    marginTop: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 10,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  sucursalTitle: {
    fontSize: 20,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  sucursalScrollView: {
    maxHeight: 200,
    width: '100%',
  },
  sucursalItem: {
    marginBottom: 10,
    backgroundColor: '#EFEFEF',
    padding: 10,
    borderRadius: 5,
  },
  sucursalText: {
    fontSize: 16,
    color: '#333',
  },
});

const ProductoCard = ({ producto, onPress, userId }) => {
  const [cantidad, setCantidad] = useState('');
  const [id_prod, setId_prod] = useState('');
  const [stockDisponible, setStockDisponible] = useState(0);
  const [error, setError] = useState('');

  useEffect(() => {
    setId_prod(producto.id_prod);
    setStockDisponible(producto.stock); 
  }, [producto.id_prod, producto.stock]);

  const handlePress = () => {
    if (cantidad.trim() === '') {
      Toast.show({
        type: 'error',
        text1: 'Cantidad',
        text2: `Por favor ingresa una cantidad válida`,
      });
      return;
    }

    if (/^\d+$/.test(cantidad)) {
      if (parseInt(cantidad) > 0 && parseInt(cantidad) <= stockDisponible) {
        onPress(producto, cantidad, userId);
        setError('');
        Toast.show({
          type: 'success',
          text1: 'Producto agregado al carrito',
          text2: `${producto.grano} añadido al carrito.`,
        });
      } else if (parseInt(cantidad) === 0) {
        Toast.show({
          type: 'error',
          text1: 'Cantidad',
          text2: `Elige una cantidad mayor a 0`,
        });
      } else {
        Toast.show({
          type: 'info',
          text1: 'Inventario',
          text2: `No hay suficiente producto disponible`,
        });
      }
    } else {
      Toast.show({
        type: 'error',
        text1: 'Cantidad',
        text2: `Por favor ingresa solo números enteros positivos`,
      });
    }
  };


  const handleCantidadChange = (text) => {
    if (/^\d*$/.test(text)) {
      setCantidad(text); 
    } else {
      Toast.show({
        type: 'error',
        text1: 'Cantidad',
        text2: `Por favor ingresa numeros positivos   `,
      });
    }
  };

  return (
    <View style={styles.card}>
      <ImageBackground
        source={{ uri: producto.imag }}
        style={styles.image}
      >
        <Text style={styles.title}>{producto.grano}</Text>
        <Text style={styles.description}>{producto.descripcion}</Text>
        <Text style={styles.title}>${producto.precio}</Text>
        <View style={styles.inputContainer}>
        <Picker
  selectedValue={cantidad}
  style={styles.input}
  onValueChange={(itemValue) => setCantidad(itemValue)}
>
  <Picker.Item label="Selecciona una cantidad" value="" />
  {[...Array(4)].map((_, index) => (
    <Picker.Item key={index} label={`${(index + 1) * 50} g`} value={`${(index + 1) * 50}`} />
  ))}
</Picker>




        </View>
        <TouchableOpacity style={styles.button} onPress={handlePress}>
          <Text style={styles.buttonText}>Agregar al carrito</Text>
        </TouchableOpacity>
        {error !== '' && <Text style={{ color: 'red', textAlign: 'center' }}>{error}</Text>}
      </ImageBackground>
    </View>
  );
};

export function CatalogoStack({ navigation }) {
  const screenOptions = {
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: '#735634',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  const FondoCatalogo = ({ children }) => (
    <ImageBackground
      source={{ uri: 'https://i.pinimg.com/originals/27/44/ec/2744ec5f832fa47f87272b7d911b6019.jpg' }}
      style={{ flex: 1, resizeMode: 'cover', justifyContent: 'center' }}
    >
      <View style={{ alignItems: 'center', marginTop: 0 }}>
        <Image
          source={require('../../assets/Moli_Magic.jpg')} 
          style={{ width: '100%', height: 180  }}
        />
      </View>
      {children}
    </ImageBackground>
  );
  

  const [productos, setProductos] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [userId, setUserId] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [sucursales, setSucursales] = useState([]);
  const [selectedSucursal, setSelectedSucursal] = useState(null);

  useEffect(() => {
    fetchDataFromStorage();
    fetchProductos();
    fetchSucursales();
  }, []);

  const fetchDataFromStorage = async () => {
    const storedUserId = await AsyncStorage.getItem('userId');
    const storedEmail = await AsyncStorage.getItem('email');
    if (storedUserId && storedEmail) {
      setUserId(storedUserId);
      setUserEmail(storedEmail);
    } else {
      navigation.navigate('Login'); // Redirigir al inicio de sesión si no está autenticado
    }
  };

  const fetchSucursales = () => {
    fetch('http://dtai.uteq.edu.mx/~timcru213/apis/sucursales.php')
      .then(response => response.json())
      .then(data => {
        setSucursales(data);
      })
      .catch(error => {
        console.error('Error fetching sucursales: ', error);
      });
  };
  

  const handleSucursalSelect = (idSucursal) => {
    setSelectedSucursal(idSucursal);
    AsyncStorage.setItem('selectedSucursal', JSON.stringify(idSucursal)); // Guarda la sucursal seleccionada
    fetchProductos(idSucursal); // Pasar el ID de la sucursal seleccionada a fetchProductos
  };
  
  
  const fetchProductos = (idSucursal) => {
    setRefreshing(true);
    let url = idSucursal ? `http://dtai.uteq.edu.mx/~timcru213/apis/productos.php?idSucursal=${idSucursal}` : 'http://dtai.uteq.edu.mx/~timcru213/apis/productos.php';
    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error('Error al obtener productos');
        }
        return response.json();
      })
      .then(data => {
        if (data && data.length > 0) { 
          setProductos(data);
        } else {
          console.log('No se encontraron productos.');
          setProductos([]);
        }
        setRefreshing(false);
      })
      .catch(error => {
        // No hacer nada en caso de error
        setRefreshing(false);
      });
  };
  
  const SucursalSelection = () => (
    <View style={styles2.sucursalContainer}>
      <Text style={styles2.sucursalTitle}>Selecciona una sucursal:</Text>
      <ScrollView style={styles2.sucursalScrollView}>
        {sucursales.map((sucursal, index) => (
          <TouchableOpacity key={index} style={styles2.sucursalItem} onPress={() => handleSucursalSelect(sucursal.id_suc)}>
            <Text style={styles2.sucursalText}>{sucursal.nombre_suc}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  const addToCart = (producto, cantidad, userId) => {
    console.log('Producto agregado al carrito:', producto, 'Cantidad:', cantidad, 'Sucursal', selectedSucursal);
    const item = { 
      cantidad: cantidad, 
      id_inv: producto.id_inv, 
      id_vent: producto.id_vent,
      id_prod: producto.id_prod, 
      precio: producto.precio,
      userId: userId,
      sucursalId: selectedSucursal 
    };
    enviarCarritoAlServidor(item);
};

  

const enviarCarritoAlServidor = async (carrito) => {
  try {
    const response = await fetch('http://dtai.uteq.edu.mx/~timcru213/apis/carrito.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(carrito), 
    });
    if (!response.ok) {
      throw new Error('Error al enviar carrito al servidor');
    }
    const data = await response.json();
    // Mostrar una alerta en el frontend para indicar que el producto se ha agregado al carrito
    Toast.show({
      type: 'success',
      text1: 'Producto Agregado',
      text2: 'El producto se ha agregado correctamente al carrito.',
    });
  } catch (error) {
    // Mostrar una alerta en el frontend para indicar que ha ocurrido un error al agregar el producto al carrito
    Toast.show({
      type: 'error',
      text1: 'Error',
      text2: 'Ha ocurrido un error al agregar el producto al carrito. Por favor, inténtalo de nuevo más tarde.',
    });
  }
};

  

  const handleLogout = async () => {
    try {
      // Limpia los datos relevantes en AsyncStorage
      await AsyncStorage.removeItem('isLoggedIn');
      await AsyncStorage.removeItem('userId');
      await AsyncStorage.removeItem('email');
      await AsyncStorage.removeItem('selectedSucursal'); // Elimina la sucursal seleccionada
      await AsyncStorage.removeItem('historial'); // Elimina el historial
      setSelectedSucursal(null); // Establece la sucursal seleccionada como null
      setProductos([]); // Limpia la lista de productos
  
      // Envía una señal de cierre de sesión a la pantalla principal
      await AsyncStorage.setItem('sessionClosed', 'true');
  
      // Redirige al usuario a la pantalla de inicio de sesión
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'Login' }],
        })
      );
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    }
  };
  
  

  const Restaurantes = () => (
    <ScrollView nestedScrollEnabled={true}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
        {productos.map((producto, index) => (
          <ProductoCard
            key={index}
            producto={producto}
            onPress={addToCart}
            userId={userId}
          />
        ))}
      </View>
    </ScrollView>
  );
  

  return (
    <ScrollView
      contentContainerStyle={{ flexGrow: 1 }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={() => fetchProductos(selectedSucursal)}
        />
      }
    >
      <Stack.Navigator screenOptions={screenOptions}>
        <Stack.Screen
          name={vista.Catalogo.tab}
          options={{ title: "MOLI MAGIC" }}
        >
          {(props) => (
            <FondoCatalogo {...props}>
              <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                <Text style={styles.logoutButtonText}>Cerrar Sesión</Text>
              </TouchableOpacity>
              {selectedSucursal ? <Restaurantes userId={userId} /> : <SucursalSelection />}
              <View style={styles.userDataContainer}>
              
              </View>
            </FondoCatalogo>
          )}
        </Stack.Screen>
      </Stack.Navigator>
      <Toast ref={(ref) => Toast.setRef(ref)} />
      <Footer/>
    </ScrollView>
  )
}

const styles3 = StyleSheet.create({
  footerContainer: {
    backgroundColor: '#f2f2f2',
    paddingVertical: 10,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  socialIcon: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  copyrightText: {
    fontSize: 12,
    color: '#555',
  },
});

const Footer = () => {
  const handleFacebookPress = () => {
    Linking.openURL('https://www.facebook.com/timmm31/');
  };

  const handleWhatsAppPress = () => {
    Linking.openURL('https://chat.whatsapp.com/https://chat.whatsapp.com/JoCpiTw46HFBCOshLDwfFj');
  };
  const handleInstagramPress = () => {
    Linking.openURL('https://www.instagram.com/tu_perfil');
  };

  return (
    <View style={styles3.footerContainer}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        {/* Aquí están las URL de las imágenes de redes sociales */}
        <TouchableOpacity onPress={handleFacebookPress}>
          <Image
            source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/2023_Facebook_icon.svg/2048px-2023_Facebook_icon.svg.png' }} // Reemplaza con la URL del icono de Facebook
            style={styles3.socialIcon}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleWhatsAppPress}>
          <Image
            source={{ uri: 'https://png.pngtree.com/png-clipart/20221019/original/pngtree-whatsapp-mobile-software-icon-png-image_8704828.png' }} // Reemplaza con la URL del icono de WhatsApp
            style={styles3.socialIcon}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleInstagramPress}>
          <Image
            source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/1200px-Instagram_icon.png' }} // Reemplaza con la URL del icono de Instagram
            style={styles3.socialIcon}
          />
        </TouchableOpacity>
      </View>
      <Text style={styles3.copyrightText}>
        © 2024 Moli Magic. Derechos Reservados.
      </Text>
    </View>
  );
};

