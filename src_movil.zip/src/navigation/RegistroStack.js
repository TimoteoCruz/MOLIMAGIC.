import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { vista } from '../utils/nombreVista';
import AgregarRegistroVista from '../vistas/Registro/AgregarRegistroVista';
import Registro from '../vistas/Registro/Registro';

const Stack = createNativeStackNavigator();

export function RegistroStack() {
  const Opciones = {
    title: 'MoliMagic',
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name={vista.Registro.tab}
        component={Registro}
        options={Opciones}
      />
      <Stack.Screen
        name={vista.Registro.AgregarRegistroVista}
        component={AgregarRegistroVista}
        options={{ title: 'Nuevo Registro' }}
      />
    </Stack.Navigator>
  );
}
