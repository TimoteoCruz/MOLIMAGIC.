import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { vista } from "../utils/nombreVista";
import CarritoVista from "../vistas/Carrito/CarritoVista";
import Carrito from "../vistas/Carrito/Carrito";

const Stack = createNativeStackNavigator();

export function CarritoStack() {
  const Opciones = {
    title: "Carrito De Compras",
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: '#2E8B57', 
    },
    headerTintColor: '#fff', 
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name={vista.Carrito.tab}
        component={Carrito}
        options={Opciones}
      />
      <Stack.Screen
        name={vista.Carrito.CarritoVista}
        component={CarritoVista}
        options={{ title: "CARRITO" }}
      />
    </Stack.Navigator>
  );
}
