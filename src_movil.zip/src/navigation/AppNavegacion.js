import React, { useState, useEffect } from 'react';
import { ActivityIndicator, View, Alert } from 'react-native';
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Icon } from "react-native-elements";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native'; // Importa useNavigation
import { vista } from "../utils/nombreVista";
import { CatalogoStack } from "./CatalogoStack";
import { HistorialStack } from "./HistorialStack";
import { CarritoStack } from "./CarritoStack";
import { LoginStack } from "./LoginStack";
import { RegistroStack } from "./RegistroStack";
import { ALERT_TYPE, Dialog, AlertNotificationRoot, Toast } from 'react-native-alert-notification';


const Tab = createBottomTabNavigator();

export function AppNavegacion() {
  const [initialRouteName, setInitialRouteName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const navigation = useNavigation(); // Obtiene el objeto de navegación
  
  useEffect(() => {
    checkIfLoggedIn();
  }, []);

  const checkIfLoggedIn = async () => {
    const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
    const sessionClosed = await AsyncStorage.getItem('sessionClosed');
    if (isLoggedIn) {
      setInitialRouteName(vista.Catalogo.tab);
    } else {
      setInitialRouteName(vista.Login.tab);
      // Limpiar datos del historial al cerrar sesión
      await AsyncStorage.removeItem('productosHistorial');
    }
    setIsLoading(false);
  
    // Si se detecta que la sesión ha sido cerrada, redirige a la pantalla de inicio de sesión
    if (sessionClosed) {
      // Limpia la señal de cierre de sesión
      await AsyncStorage.removeItem('sessionClosed'); 
      // Limpia el estado de autenticación
      await AsyncStorage.removeItem('isLoggedIn');
      // Recarga todas las páginas
      reloadPages();
    }
  };

  const reloadPages = () => {
    // Reinicia la navegación a la página de inicio
    navigation.reset({
      index: 0,
      routes: [{ name: vista.Login.tab }],
    });
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <Tab.Navigator
      initialRouteName={initialRouteName}
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: "#224e79",
        tabBarInactiveTintColor: "#7c7c7c",
        showIcon: true,
        tabBarIcon: ({ color, size }) => screenOptions(route, color, size),
      })}
    >
      <Tab.Screen
        name={vista.Login.tab}
        options={{ title: "Login" }} 
        component={LoginStack}
        listeners={({ navigation }) => ({
          tabPress: async (e) => {
            const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
            if (isLoggedIn) {
              e.preventDefault();
              Alert.alert(
                'Sesión Activa',
                'Ya has iniciado sesión.',
                [{ text: 'OK', onPress: () => navigation.navigate(vista.Catalogo.tab) }]
              );
            }
          },
        })}
      />
      <Tab.Screen
        name={vista.Catalogo.tab}
        options={{ title: "Catalogo" }}
        component={CatalogoStack}
        listeners={({ navigation }) => ({
          tabPress: async (e) => {
            const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
            if (!isLoggedIn) {
              e.preventDefault();
              Alert.alert(
                'Iniciar Sesión',
                'Debes iniciar sesión para acceder a esta sección.',
                [{ text: 'OK', onPress: () => navigation.navigate(vista.Login.tab) }]
              );
            }
          },
        })}
      />
      <Tab.Screen
        name={vista.Historial.tab}
        options={{ title: "Historial" }} 
        component={HistorialStack}
        listeners={({ navigation }) => ({
          tabPress: async (e) => {
            const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
            if (!isLoggedIn) {
              e.preventDefault();
              Alert.alert(
                'Iniciar Sesión',
                'Debes iniciar sesión para acceder a esta sección.',
                [{ text: 'OK', onPress: () => navigation.navigate(vista.Login.tab) }]
              );
            }
          },
        })}
      />
      <Tab.Screen
        name={vista.Carrito.tab}
        options={{ title: "Carrito" }} 
        component={CarritoStack}
        listeners={({ navigation }) => ({
          tabPress: async (e) => {
            const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
            if (!isLoggedIn) {
              e.preventDefault();
              Alert.alert(
                'Iniciar Sesión',
                'Debes iniciar sesión para acceder a esta sección.',
                [{ text: 'OK', onPress: () => navigation.navigate(vista.Login.tab) }]
              );
            }
          },
        })}
      />
      <Tab.Screen
        name={vista.Registro.tab}
        options={{ title: "Registro" }} 
        component={RegistroStack}
        listeners={({ navigation }) => ({
          tabPress: async (e) => {
            const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
            if (isLoggedIn) {
              e.preventDefault();
              Alert.alert(
                'Sesión Activa',
                'Ya has iniciado sesión.',
                [{ text: 'OK', onPress: () => navigation.navigate(vista.Catalogo.tab) }]
              );
            }
          },
        })}
      />
    </Tab.Navigator>
  );
}

function screenOptions(route, color, size) {
  let iconName;

  if (route.name === vista.Catalogo.tab) iconName = "home-outline";
  if (route.name === vista.Historial.tab) iconName = "book";
  if (route.name === vista.Carrito.tab) iconName = "cart";
  if (route.name === vista.Login.tab) iconName = "login";
  if (route.name === vista.Registro.tab) iconName = "login";

  return (
    <Icon type="material-community" name={iconName} color={color} size={size} />
  );
}
