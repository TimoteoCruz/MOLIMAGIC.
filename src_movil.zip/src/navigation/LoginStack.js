import {createNativeStackNavigator} from "@react-navigation/native-stack";
import { vista } from "../utils/nombreVista";
import AgregarLoginVista from "../vistas/Login/AgregarLoginVista";
import Login from "../vistas/Login/Login";


const Stack = createNativeStackNavigator();

export  function LoginStack(){
    const Opciones = {
        title: "MoliMagic"
    };

    return(
        <Stack.Navigator>
            <Stack.Screen name = {vista.Login.Login}
            component ={Login}
            options={Opciones}/>
            <Stack.Screen name={vista.Login.AgregarLoginVista}
            component={AgregarLoginVista}
            options={{title:"Nuevo Login"}} />
        </Stack.Navigator>
    )

}
