import React, { useState, useEffect } from 'react';
import { ImageBackground, View, StyleSheet, Text, TouchableOpacity, ScrollView, RefreshControl } from 'react-native';
import { useNavigation } from "@react-navigation/native"; 
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { vista } from "../utils/nombreVista";
import { Ionicons } from '@expo/vector-icons';
import moment from 'moment';
import { Table, Row } from 'react-native-table-component';
import AsyncStorage from '@react-native-async-storage/async-storage';



const Stack = createNativeStackNavigator();

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FDEE8D',
  },
  detailsContainer: {
    backgroundColor: '#F8F0BE',
    padding: 0,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20, 
    alignSelf: 'stretch',
    marginHorizontal: 10,
    marginVertical: 10,
    borderRadius: 15,
  },
  detailText: {
    fontWeight: 'bold',
    fontSize: 22,
    marginBottom: 5,
    textAlign: 'left', 
  },
  table: {
    width: '90%',
    borderRadius: 10,
  },
  row: { height: 60 }, 
  text: { textAlign: 'center', fontWeight: 'bold', fontSize: 20 }, 
  card: {
    width: '95%', 
    margin: 10,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 5,
    position: 'relative', 
    backgroundColor: '#FFFFFF', 
  },
  image: {
    width: '100%',
    height: 200,
    justifyContent: 'flex-end',
  },
  title: {
    fontSize: 24,
    color: 'black',
    padding: 10,
  },
  button: {
    backgroundColor: '#735634',
    padding: 10,
    alignItems: 'center',
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  verifiedIcon: {
    backgroundColor: 'green',
    borderRadius: 10,
    padding: 5,
  },
  verifiedText: {
    color: 'green',
    fontWeight: 'bold',
  },
});

const ProductoCard = ({ producto, onPress }) => {
  const formatFecha = (fecha) => {
    const parsedDate = moment(fecha);
    if (parsedDate.isValid()) {
      return parsedDate.format('DD/MM/YYYY');
    } else {
      return 'Fecha inválida';
    }
  };
    
  return (
    <View style={styles.card}>
      <View style={{ justifyContent: 'center', alignItems: 'center' }}>
        <Ionicons name="checkmark-done" size={24} color="white" style={styles.verifiedIcon} />
        <Text style={styles.verifiedText}>Compra realizada</Text>
      </View>
      <Text style={styles.title}>FECHA: <Text>{formatFecha(producto.fech_ven)}</Text></Text>
      <Text style={styles.title}>Precio: ${producto.prec_prod}</Text>
      <Text style={styles.title}>CANTIDAD: {producto.cantidad}</Text>
      <TouchableOpacity style={styles.button} onPress={onPress}>
        <Text style={styles.buttonText}>Ver Detalles</Text>
      </TouchableOpacity>
    </View>
  );
};

export function HistorialStack() {
  const screenOptions = {
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: '#735634',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  const FondoCatalogo = ({ children }) => (
    <ImageBackground
      style={{ flex: 1, resizeMode: 'cover', justifyContent: 'center', backgroundColor: 'lightyellow' }} 
    >
      {children}
    </ImageBackground>
  );

  const [productos, setProductos] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const navigation = useNavigation(); 

  const fetchData = async () => {
    try {
      // Obtener userId del AsyncStorage
      const userId = await AsyncStorage.getItem('userId');
      console.log(userId); // Asegúrate de que userId se esté recuperando correctamente
    
      if (userId) {
        // Enviar userId al backend a través de la API
        const response = await fetch(`http://dtai.uteq.edu.mx/~timcru213/apis/detalleVenta.php?userId=${userId}`, {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json'
  }
});

        const data = await response.json();
        setProductos(data || []); // Si data es null o undefined, asigna un array vacío
        setRefreshing(false);
      } else {
        setRefreshing(false);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setRefreshing(false);
    }
  };
  

  useEffect(() => {
    fetchData();
  }, []);

  const handleNavigation = (producto) => {
    navigation.navigate('DetallesProducto', { producto });
  };

  const Historial = () => (
    <ScrollView
      style={{ flex: 1 }}
      contentContainerStyle={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={fetchData}
        />
      }
    >
     {productos && productos.length > 0 ? (
  productos.map((producto, index) => (
    <ProductoCard
      key={index}
      producto={producto}
      onPress={() => handleNavigation(producto)}
    />
  ))
) : (
  <Text style={styles.title}>No Tienes Ventas...</Text>
)}

    </ScrollView>
  );
  
  

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name={vista.Historial.tab}
        options={{ title: "MOLI MAGIC" }}
      >
        {(props) => (
          <FondoCatalogo {...props}>
            <Historial />
          </FondoCatalogo>
        )}
      </Stack.Screen>
      <Stack.Screen name="DetallesProducto" component={DetallesProducto} />
    </Stack.Navigator>
  )
}

const DetallesProducto = ({ route }) => {
  const { producto } = route.params;

  const formatFecha = (fecha) => {
    const parsedDate = moment(fecha);
    if (parsedDate.isValid()) {
      return parsedDate.format('DD/MM/YYYY');
    } else {
      return 'Fecha inválida';
    }
  };
  

  const total = producto.cantidad * producto.prec_prod;

  return (
    <View style={styles.container}>
      <View style={styles.detailsContainer}>
      <Text style={styles.title}>FECHA: <Text>{formatFecha(producto.fech_ven)}</Text></Text>
        <Text style={[styles.detailText, { marginBottom: 20 }]}></Text>
        <Text style={[styles.detailText, { marginBottom: 20 }]}>Sucursal: Soriana</Text>
        <Table style={styles.table} borderStyle={{ borderWidth: 1, borderColor: '#000000' }}>
          <Row
            data={['Producto','Precio','Cantidad','Total' ]}
            style={[styles.row, { backgroundColor: '#633C00' }]}
            textStyle={[styles.text, { color: '#ffffff', fontSize: 20 }]}
          />
          <Row
            data={[producto.grano, `$${producto.prec_prod}`, producto.cantidad, `$${total}`]} // Cambio aquí
            style={styles.row}
            textStyle={[styles.text, { fontSize: 20 }]} 
          />
        </Table>
        <Text style={styles.detailText}>Total: <Text>${total}</Text></Text>
      </View>
    </View>
  );
};
