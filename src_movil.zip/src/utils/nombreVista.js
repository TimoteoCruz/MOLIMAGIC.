import Carrito from "../vistas/Carrito/Carrito";


const RegistroStack = {
    tab: "Registro",
    AgregarRegistroVista: "CarritoVista",
};

const CatalogoStack = {
    tab: "Catalogo",
    CatalogoVista: "AgregaRestauranteVista",
};



const HistorialStack = {
    tab: "Historial",
    HistorialVista: "AgregarBuscadorVista",
};

const CarritoStack = {
    tab: "Carrito",
    CarritoVista: "CarritoVistaview",
};

const LoginStack = {
    tab: "Login",
    Login: "LoginScreen",
    AgregarLoginVista: "AgregarLoginVista",
};





export const vista = {
    Login : LoginStack,
    Catalogo: CatalogoStack,
    Historial: HistorialStack,
    Carrito: CarritoStack,
    Registro: RegistroStack,
};
