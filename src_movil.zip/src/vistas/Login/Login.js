import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    checkIfLoggedIn();
  }, []);

  const checkIfLoggedIn = async () => {
    const isLoggedIn = await AsyncStorage.getItem('isLoggedIn');
    if (isLoggedIn) {
      await fetchDataFromStorage();
      const selectedSucursal = await AsyncStorage.getItem('selectedSucursal');
      if (selectedSucursal) {
        setSelectedSucursal(JSON.parse(selectedSucursal)); // Establece la sucursal seleccionada nuevamente
      }
      navigation.navigate('Catalogo');
    }
  };
  

  const handleLogin = async () => {
    try {
      const tipo_us = 'client'; // Tipo de usuario, asegúrate de que sea el valor correcto según tu lógica
      const response = await axios.post('http://dtai.uteq.edu.mx/~timcru213/apis/login.php', { email, password, tipo_us });
      if (response.status === 200) {
        // Si la respuesta es exitosa, guardamos la información de la sesión en AsyncStorage
        await AsyncStorage.setItem('isLoggedIn', 'true');
        await AsyncStorage.setItem('userId', response.data.id_us.toString());
        await AsyncStorage.setItem('email', email);
        // Mostramos un mensaje de inicio de sesión exitoso y navegamos a la siguiente pantalla
        Alert.alert('Inicio de sesión exitoso', response.data.message, [{ text: 'OK', onPress: () => navigation.navigate('Catalogo') }]);
      } else {
        // Si la respuesta no es exitosa, mostramos un mensaje de error
        Alert.alert('Error', 'Inicio de sesión fallido');
      }
      console.log(response.data);
    } catch (error) {
      // Si hay un error en la solicitud, mostramos un mensaje de error con la descripción del error proporcionada por la API
      Alert.alert('Error', error.response.data.error);
    }
  };
  

  const handleRegister = () => {
    navigation.navigate('Registro'); 
  };

  return (
    <ImageBackground source={require('../fondo6.png')} style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.title}>Inicio de Sesión</Text>
        <View style={styles.inputContainer}>
          <Text style={[styles.label, styles.centerText]}>Correo Electrónico</Text>
          <TextInput
            style={styles.input}
            placeholder="Ingresa tu usuario"
            value={email}
            onChangeText={setEmail}
          />
          <Text style={[styles.label, styles.centerText]}>Contraseña</Text>
          <TextInput
            style={styles.input}
            placeholder="Ingresa tu contraseña"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />
         
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={[styles.button, {backgroundColor: '#66E172'}]} onPress={handleLogin}>
            <Text style={styles.buttonText}>Iniciar sesión</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, {backgroundColor: '#66E172'}]} onPress={handleRegister}>
            <Text style={styles.buttonText}>Registro</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    color: 'white',
  },
  subtitle: {
    fontSize: 18,
    color: 'white',
  },
  parrafo: {
    fontSize: 18,
    color: 'white',
    textDecorationLine: 'underline',
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
    color: 'white',
  },
  inputContainer: {
    width: '80%',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: 'white',
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    padding: 10,
    marginBottom: 10,
    color: 'black',
  },
  forgotPasswordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonContainer: {
    width: '80%',
  },
  button: {
    backgroundColor: '#66E172',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  centerText: {
    textAlign: 'center',
  },
});
