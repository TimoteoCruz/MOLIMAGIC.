import React from 'react';
import { View, Text } from 'react-native';
import { Button } from 'react-native-elements';
import { vista } from '../../utils';

export default function Catalogo(props) {
  const { navigation } = props;

  const irACatalogo = () => {
    console.log("Ir a Restaurante");
    navigation.navigate(vista.Catalogo.CatalogoVista, { screen: vista.Catalogo.Catalogo });
  }

  return (
    <View>
      <Text></Text>
      
    </View>
  );
}
