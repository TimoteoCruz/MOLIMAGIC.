import React from 'react';
import { View, Text } from 'react-native';

export default function AgregaRegistroVista() {
  return(
    <View>
      <Text>AgregarCuentaVista</Text>
    </View>
  );
}
 