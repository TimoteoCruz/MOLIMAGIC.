import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ImageBackground, Alert } from 'react-native';
import { vista } from '../../utils'; 

export default function Registro({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nombre, setNombre] = useState('');
  const [apaterno, setApaterno] = useState('');

  const validarCorreo = (email) => {
    // Expresión regular para validar correo electrónico
    const expresionRegular = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return expresionRegular.test(email);
  };

  const handleRegistro = async () => {
    if (!validarCorreo(email)) {
      Alert.alert('Correo inválido', 'Por favor ingresa un correo electrónico válido.');
      return;
    }
  
    try {
      const response = await fetch('http://dtai.uteq.edu.mx/~timcru213/apis/registro.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          password,
          nombre,
          apaterno,
        }),
      });
  
      const data = await response.json();
  
      if (response.ok) {
        Alert.alert('Registro exitoso', data.message, [{ text: 'OK', onPress: () => navigation.navigate('Login') }]);
      } else {
        Alert.alert('Error', data.error);
      }
    } catch (error) {
      console.error('Error al registrar:', error);
      Alert.alert('Error', 'Hubo un error al intentar registrar. Por favor, intenta de nuevo más tarde.');
    }
  };
  

  const handleLogin = () => {
    navigation.navigate('Login'); 
  }

  return (
    <ImageBackground source={require('../fondo6.png')} style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.title}>Registro</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Correo electrónico"
            value={email}
            onChangeText={setEmail}
          />
          <TextInput
            style={styles.input}
            placeholder="Contraseña"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />
          <TextInput
            style={styles.input}
            placeholder="Nombre"
            value={nombre}
            onChangeText={setNombre}
          />
          <TextInput
            style={styles.input}
            placeholder="Apellido"
            value={apaterno}
            onChangeText={setApaterno}
          />
        </View>
        <View style={styles.buttonContainer}>
          <Button title="Registro" onPress={handleRegistro} style={styles.button} />
        </View>
        <View style={styles.buttonContainer}>
          <Button title="Iniciar Sesión" onPress={handleLogin} style={styles.button} />
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    color: 'white',
  },
  inputContainer: {
    width: '80%',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: 'white',
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    padding: 10,
    marginBottom: 10,
    color: 'black',
  },
  buttonContainer: {
    width: '80%',
    marginBottom: 10, 
  },
  button: {
    backgroundColor: '#66E172',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
});
