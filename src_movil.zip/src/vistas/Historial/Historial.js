import React from 'react';
import { View, Text } from 'react-native';
import { Button } from 'react-native-elements';
import { vista } from '../../utils';

export default function Historial(props) {
  const { navigation } = props;

  const irAHistorial = () => {
    console.log("Ir a Historial");
    navigation.navigate(vista.Historial.HistorialVista, { screen: vista.Historial.Historial });
  }

  return (
    <View>
      <Text>Historial</Text>
      <Button title="Crear Historial" onPress={irAHistorial} />
    </View>
  );
}
