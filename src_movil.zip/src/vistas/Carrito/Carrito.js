import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Button, Image, TouchableOpacity, ScrollView, RefreshControl, Modal, TextInput } from 'react-native';
import Slider from '@react-native-community/slider';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Toast from 'react-native-toast-message';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#ffffcc', 
    paddingTop: 50,
  },
  title: {
    color: 'green',
    fontSize: 25,
    padding: 20,
  },
  title2: {
    color: '#green', 
    fontSize: 25,
    padding: 20,
    backgroundColor: '#ffffcc',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    backgroundColor: 'white',
  },
  button: {
    width: '45%',
    backgroundColor: 'red',
  },
  productContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    width: '80%',
  },
  productInfoContainer: {
    flexDirection: 'column', 
  },
  productImage: {
    width: 100, 
    height: 50, 
    marginRight: 10,
  },
  sliderContainer: {
    width: '100%',
    marginTop: 10,
  },
  startButtonContainer: {
    marginTop: 20,
    width: '80%',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
});

const trackColors = ['#FF5733', '#33FF57', '#D8BC07', '#AF0404'];

export default function Carrito(props) {
  const [productos, setProductos] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [pagoRealizado, setPagoRealizado] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiration, setCardExpiration] = useState('');
  const [cardCVV, setCardCVV] = useState('');
  const [mostrarEmpezar, setMostrarEmpezar] = useState(true);
  const [resetPage, setResetPage] = useState(false);
  const [procesoEnCurso, setProcesoEnCurso] = useState(false);

  // Función para formatear el número de tarjeta
  const formatCardNumber = (input) => {
    // Eliminar cualquier caracter que no sea un dígito
    let digitsOnly = input.replace(/\D/g, '');
    // Insertar un espacio después de cada grupo de cuatro dígitos
    let formatted = digitsOnly.replace(/(\d{4})/g, '$1 ').trim();
    return formatted;
  }

  // Función para formatear la fecha de expiración
  const formatExpirationDate = (input) => {
    // Eliminar cualquier caracter que no sea un dígito
    let digitsOnly = input.replace(/\D/g, '');
    // Insertar una barra después de los primeros dos dígitos
    let formatted = digitsOnly.replace(/(..)/g, '$1/').substring(0, 5);
    return formatted;
  }



  useEffect(() => {
    obtenerProductosCarrito();
  }, []);

  const obtenerProductosCarrito = async () => {
    try {
      const userId = await AsyncStorage.getItem('userId');
      const selectedSucursal = await AsyncStorage.getItem('selectedSucursal');
      if (userId !== null && selectedSucursal !== null) {
        fetchProductosCarrito(userId, selectedSucursal);
      } else {
        console.log('No se encontró el ID de usuario o la sucursal seleccionada');
      }
    } catch (error) {
      console.error('Error al obtener el ID de usuario o la sucursal seleccionada:', error);
    }
  };
  
  const fetchProductosCarrito = async (userId, selectedSucursal) => {
    try {
      console.log('Enviando userId y selectedSucursal a la API:', userId, selectedSucursal);
      const response = await fetch(`http://dtai.uteq.edu.mx/~timcru213/apis/mcarrito.php?userId=${userId}&selectedSucursal=${selectedSucursal}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json(); // Analizar directamente la respuesta JSON
      console.log('Datos recibidos de la API:', data);
  
      if (response.ok) {
        if (Array.isArray(data.productos) && data.productos.length > 0) {
          setProductos(data.productos);
          setPagoRealizado(false);
        } else {
          console.error('La respuesta de la API no contiene datos válidos:', data);
        }
      } else {
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  };
  

  const eliminarProducto = (idCar) => {
    fetch('http://dtai.uteq.edu.mx/~timcru213/apis/eliminarProducto.php', {  
      method: 'POST',
      body: JSON.stringify({ id_car: idCar }), 
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then(response => {
      console.log('Response from server:', response);
      if (response.ok) {
        Toast.show({
          type: 'success',
          text1: 'Producto Eliminado',
          text2: 'El producto se ha eliminado del carrito.',
          visibilityTime: 3000,
          autoHide: true,
        });
      }
    })
    .catch(error => console.error('Error eliminando producto:', error));
  };

  const handlePagar = () => {
    setModalVisible(true);
  };

  const handleSubmitPayment = async () => {
    try {
      // Verificar si todos los campos están llenos
      if (cardNumber.length !== 19 || cardExpiration.length !== 5 || cardCVV.length !== 3) {
        Toast.show({
          type: 'error',
          text1: 'Campos incompletos',
          text2: 'Por favor, completa todos los campos correctamente para continuar el pago.',
          visibilityTime: 3000,
          autoHide: true,
        });
        return;
      }
  
      const userId = await AsyncStorage.getItem('userId');
      console.log('ID de usuario:', userId);
      const selectedSucursal= await AsyncStorage.getItem('selectedSucursal');
      console.log('ID de usuario:', selectedSucursal);
  
      console.log('Enviando userId a la API:', userId, selectedSucursal);
      const response = await fetch(`http://dtai.uteq.edu.mx/~timcru213/apis/mcarrito.php?userId=${userId}&selectedSucursal=${selectedSucursal}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      console.log('Datos recibidos de la API:', data);
  
      if (data && data.productos && data.productos[0] && data.productos[0].id_vent) {
        const id_vent = data.productos[0].id_vent;
  
        const updateResponse = await fetch('http://dtai.uteq.edu.mx/~timcru213/apis/actualizarVenta.php', {
          method: 'POST',
          body: JSON.stringify({ id_vent }),
          headers: {
            'Content-Type': 'application/json',
          },
        });
        const updateData = await updateResponse.json();
        console.log('Datos recibidos al actualizar la venta:', updateData);
  
        if (updateData.error) {
          console.error('Error al actualizar la venta:', updateData.error);
          return;
        }
  
        console.log('Venta actualizada correctamente:', updateData.message);
  
        // Aquí puedes realizar cualquier otra acción necesaria después de actualizar la venta
  
        setPagoRealizado(true); // Actualiza el estado de pagoRealizado a true
      } else {
        console.error('No se pudo obtener el ID de venta de la respuesta de la API:', data);
      }
    } catch (error) {
      console.error('Error al procesar el pago:', error);
    }
  };
  

  useEffect(() => {
    if (pagoRealizado) {
      Toast.show({
        type: 'success',
        text1: 'Pago Realizado Correctamente',
        visibilityTime: 3000,
        autoHide: true,
      });
    }
  }, [pagoRealizado]);


  const handleEmpezar = async () => {
    try {
      if (productos.length === 0) {
        // Mostrar un mensaje si no hay productos para moler
        Toast.show({
          type: 'error',
          text1: 'No hay productos',
          text2: 'No hay productos para moler.',
          visibilityTime: 3000,
          autoHide: true,
        });
        return;
      }
  
      const userId = await AsyncStorage.getItem('userId');
      const datos = {
        userId: userId,
        productos: productos.map(producto => ({
          grano: producto.grano,
          sliderValue: producto.sliderValue,
          cantidad: producto.cantidad // Añadir la cantidad al objeto de producto
        })),
      };
  
      console.log('Datos enviados desde el frontend:', datos);
  
      // Antes de enviar la solicitud, verificar si hay un proceso en curso
      const responseProcesoEnCurso = await fetch('https://pmolimagic-default-rtdb.firebaseio.com/procesoEnCurso.json');
      const procesoEnCursoData = await responseProcesoEnCurso.json();
      const procesoEnCurso = procesoEnCursoData === true;
  
      if (procesoEnCurso) {
        Toast.show({
          type: 'error',
          text1: 'Proceso en curso',
          text2: 'Hay un pedido en proceso. Intente nuevamente más tarde.',
          visibilityTime: 3000,
          autoHide: true,
        });
        return;
      }
  
      // Mostrar la alerta antes de enviar los datos al servidor
      Toast.show({
        type: 'success',
        text1: 'Proceso',
        text2: `Realizando su pedido`,
      });
  
      const response = await fetch('http://dtai.uteq.edu.mx/~timcru213/apis/maquina.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(datos),
      });
  
      if (response.ok) {
        console.log('Datos enviados correctamente');
        setProductos([]);
        setPagoRealizado(true);
      } else {
        Toast.show({
          type: 'error',
          text1: 'No hay productos',
          text2: `O hay un pedido en proceso   `,
        });
      }
    } catch (error) {
      console.error('Error al procesar el pago:', error);
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Hubo un error al enviar los datos.',
        visibilityTime: 3000,
        autoHide: true,
      });
    }
  };
  
  
  const handleSliderChange = (index, value) => {
    const updatedProductos = [...productos];
    updatedProductos[index].sliderValue = value;
    setProductos(updatedProductos);
  };

  return (
    <ScrollView
      contentContainerStyle={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={obtenerProductosCarrito} />}
    >
      {pagoRealizado ? (
        <Text style={styles.title2}>Pago Realizado Correctamente</Text>
      ) : (
        <Text style={styles.title2}></Text>
      )}
      <Text style={styles.title}>Productos elegidos:</Text>
      <ScrollView style={{ maxHeight: 340, marginBottom: 20 }}>
        {productos.length > 0 ? (
          productos.map((producto, index) => (
            <Producto
              key={index}
              id_car={producto.id_car}
              nombre={producto.grano}
              precio={producto.precio}
              imagen={producto.imag}
              cantidad={producto.cantidad}
              eliminarProducto={eliminarProducto}
              sliderValue={producto.sliderValue}
              setSliderValue={(value) => handleSliderChange(index, value)}
            />
          ))
        ) : (
          <Text>No hay productos, Desliza para actualizar</Text>
        )}
      </ScrollView>

      {productos.length > 0 && !pagoRealizado && (
        <View style={styles.startButtonContainer}>
          <Button
            title="Pagar"
            color="green"
            onPress={handlePagar}
          />
        </View>
      )}
      {pagoRealizado && (
        <View style={styles.startButtonContainer}>
          <Button
            title="Empezar"
            color="green"
            onPress={handleEmpezar}
          />
        </View>
      )}

      {/* Modal para el formulario de tarjeta */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(false);
        }}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
              <Text style={{ fontSize: 20 }}>x</Text>
            </TouchableOpacity>
            <Text style={{ fontSize: 20, marginBottom: 10 }}>Ingresa Los Datos De La Tarjeta:</Text>
            <TextInput
              style={styles.input}
              placeholder="Número de tarjeta"
              onChangeText={text => setCardNumber(formatCardNumber(text))}
              keyboardType="numeric"
              maxLength={19}
              value={cardNumber} // Añadido para que el estado se refleje correctamente
            />
            <Text></Text>
            <TextInput
              style={styles.input}
              placeholder="Fecha de expiración (MM/YY)"
              onChangeText={text => setCardExpiration(formatExpirationDate(text))}
              keyboardType="numeric"
              maxLength={5}
              value={cardExpiration} // Añadido para que el estado se refleje correctamente
            />
            <TextInput
              style={styles.input}
              placeholder="CVV"
              onChangeText={text => setCardCVV(text.replace(/\s/g, '').substring(0, 3))}
              keyboardType="numeric"
              maxLength={3}
              value={cardCVV} // Añadido para que el estado se refleje correctamente
            />
            <Button title="Pagar" onPress={handleSubmitPayment} />
          </View>
        </View>
      </Modal>

      <Toast ref={(ref) => Toast.setRef(ref)} />
    </ScrollView>
  );
}

const getTermino = (value) => {
  switch (value) {
    case 0:
      return 'entero';
    case 1:
      return 'poco';
    case 2:
      return 'medio';
    case 3:
      return 'fino';
    default:
      return '';
  }
};

const Producto = ({ id_car, nombre, precio, imagen, cantidad, eliminarProducto, sliderValue, setSliderValue }) => {
  const handleEliminarProducto = () => {
    console.log('ID del carrito a eliminar:', id_car); 
    eliminarProducto(id_car);
  };

  return (
    <View style={styles.productContainer}>
      <Image source={{ uri: imagen }} style={styles.productImage} />
      <View style={styles.productInfoContainer}>
        <Text>Nombre: {nombre}</Text>
        <Text>Precio: ${precio}</Text>
        <Text>Cantidad: {cantidad}</Text> 
        <TouchableOpacity onPress={handleEliminarProducto}>
          <Text style={{ color: 'red' }}>Eliminar</Text>
        </TouchableOpacity>
        <View style={styles.sliderContainer}>
          <Text>Selecciona El Tipo de Molido:</Text>
<Slider
  style={{ width: '100%', marginTop: 10 }}
  minimumValue={0}
  maximumValue={3}
  step={1}
  value={sliderValue ?? 0} // Establecer el valor predeterminado en 0 si sliderValue es undefined
  minimumTrackTintColor={trackColors[sliderValue ?? 0]} // Usar el valor predeterminado para obtener el color correcto
  maximumTrackTintColor="#000000"
  onValueChange={setSliderValue}
/>

          <Text>Nivel seleccionado: {getTermino(sliderValue)}</Text>
        </View>
      </View>
    </View>
  );
};
