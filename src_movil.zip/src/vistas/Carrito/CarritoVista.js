import React from 'react';
import { View, Text } from 'react-native';

export default function CarritoVista() {
  return(
    <View>
      <Text>Agrega Una Cuenta Nueva</Text>
    </View>
  );
}
